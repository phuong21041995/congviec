import os
import sys

# Xác định thư mục gốc của ứng dụng, hoạt động cho cả script và file .exe
if getattr(sys, 'frozen', False):
    basedir = os.path.dirname(sys.executable)
else:
    basedir = os.path.abspath(os.path.dirname(__file__))

class Config:
    """Set Flask configuration variables."""
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'ban-nen-thay-doi-chuoi-nay-de-bao-mat-hon'

    # --- SỬA ĐỔI ---
    # Database mặc định (chung)
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or \
        'sqlite:///' + os.path.join(basedir, 'database.db')

    # Các database khác (cá nhân) được "bind" vào
    SQLALCHEMY_BINDS = {
        'personal': os.environ.get('PERSONAL_DATABASE_URL') or \
                    'sqlite:///' + os.path.join(basedir, 'personal.db')
    }
    # --- KẾT THÚC SỬA ĐỔI ---
        
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Uploads configuration
    UPLOAD_FOLDER = os.path.join(basedir, 'uploads')
    
    # Giới hạn dung lượng file upload
    MAX_CONTENT_LENGTH = 2 * 1024 * 1024 * 1024  # 2GB
