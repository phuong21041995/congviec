import sqlite3
import os

# Danh sách database cần kiểm tra
db_paths = ['database.db', 'personal.db']

def upgrade_database(db_path):
    if not os.path.exists(db_path):
        return

    print(f"\n>>> Đang kiểm tra database: {db_path}")
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # ==========================================
        # 1. KIỂM TRA BẢNG TASK
        # ==========================================
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='task'")
        if not cursor.fetchone():
            print(f"   [!] Bảng 'task' không tồn tại. Bỏ qua.")
        else:
            cursor.execute("PRAGMA table_info(task)")
            columns_info = cursor.fetchall()
            task_columns = [info[1] for info in columns_info]
            
            # Thêm cột start_date
            if 'start_date' not in task_columns:
                print(f"   [+] Bảng task: Thêm cột 'start_date'...")
                cursor.execute("ALTER TABLE task ADD COLUMN start_date DATE")
            else:
                print(f"   [v] Bảng task: Cột 'start_date' đã tồn tại.")

            # Thêm cột daily_report_item_id
            if 'daily_report_item_id' not in task_columns:
                print(f"   [+] Bảng task: Thêm cột 'daily_report_item_id'...")
                cursor.execute("ALTER TABLE task ADD COLUMN daily_report_item_id INTEGER")
            else:
                print(f"   [v] Bảng task: Cột 'daily_report_item_id' đã tồn tại.")

        # ==========================================
        # 2. KIỂM TRA BẢNG BUILD (TÍNH NĂNG KÉO THẢ MỚI)
        # ==========================================
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='build'")
        if not cursor.fetchone():
            print(f"   [!] Bảng 'build' không tồn tại. Bỏ qua.")
        else:
            cursor.execute("PRAGMA table_info(build)")
            columns_info = cursor.fetchall()
            build_columns = [info[1] for info in columns_info]
            
            # Thêm cột position
            if 'position' not in build_columns:
                print(f"   [+] Bảng build: Thêm cột 'position'...")
                # SQLite cho phép ADD COLUMN với DEFAULT value
                cursor.execute("ALTER TABLE build ADD COLUMN position INTEGER DEFAULT 0")
            else:
                print(f"   [v] Bảng build: Cột 'position' đã tồn tại.")
                
        conn.commit()
        print(f"--- Hoàn tất cập nhật cho {db_path} ---")

    except Exception as e:
        print(f"   [X] Lỗi: {e}")
    finally:
        conn.close()

if __name__ == "__main__":
    print("==========================================")
    print("DB UPGRADE TOOL - FIX DB")
    print("==========================================")
    
    found_any = False
    for path in db_paths:
        if os.path.exists(path):
            upgrade_database(path)
            found_any = True
            
    if not found_any:
        print("Không tìm thấy file database nào.")
    else:
        print("\n[XONG] Database đã cập nhật xong, hãy khởi động lại ứng dụng!")