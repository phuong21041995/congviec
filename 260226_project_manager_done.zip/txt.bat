@echo off
REM Thư mục virtual environment (chỉnh nếu cần)
SET VENV_DIR=.venv

REM Hiển thị thông tin
ECHO [INFO] Opening command prompt and activating virtual environment...

REM Kiểm tra xem thư mục venv có tồn tại không
IF NOT EXIST "%VENV_DIR%\Scripts\activate.bat" (
    ECHO [ERROR] Virtual environment not found at "%VENV_DIR%".
    ECHO Make sure the virtual environment exists and the path is correct.
    PAUSE
    EXIT /B 1
)

REM Mở một cửa sổ cmd mới, chuyển vào thư mục hiện tại và kích hoạt venv
START "Activate Venv" cmd /k "cd /d %~dp0 && ECHO Activating %VENV_DIR% && CALL "%VENV_DIR%\Scripts\activate.bat" && TITLE VirtualEnv: %VENV_DIR%"

REM Nếu muốn kích hoạt trong cùng cửa sổ thay vì mở cửa sổ mới, bỏ comment dòng dưới và xóa hoặc giữ START trên.
:: CALL "%VENV_DIR%\Scripts\activate.bat"
