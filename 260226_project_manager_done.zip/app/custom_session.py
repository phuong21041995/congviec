from flask import session as flask_session, has_request_context
from flask_sqlalchemy.session import Session as BaseSession
from sqlalchemy.exc import UnboundExecutionError

class CustomSession(BaseSession):
    def get_bind(self, mapper=None, clause=None, **kw):
        """
        Hàm thông minh này được gọi trước mỗi câu truy vấn.
        Nó sẽ quyết định dùng engine của database nào.
        """
        # Nếu không trong một request (ví dụ: lúc khởi động app), dùng cơ chế mặc định.
        if not has_request_context():
            return super().get_bind(mapper=mapper, clause=clause, **kw)

        # Nếu đang trong một request, đọc lựa chọn của người dùng từ session
        db_key = flask_session.get('db_key')

        if db_key == 'personal':
            # --- SỬA LỖI Ở ĐÂY ---
            # Tên biến chính xác là self._db (có dấu gạch dưới)
            engine = self._db.get_engine(bind='personal')
            # --- KẾT THÚC SỬA LỖI ---
            if engine is None:
                raise UnboundExecutionError("Bind 'personal' is not configured.")
            return engine
        
        # Mặc định (hoặc khi db_key là 'shared'), dùng cơ chế gốc
        # để lấy engine mặc định (database chung).
        return super().get_bind(mapper=mapper, clause=clause, **kw)

