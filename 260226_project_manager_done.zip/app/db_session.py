from flask import session, has_request_context
from sqlalchemy.orm import sessionmaker, scoped_session
from . import db  # Import the db instance from your app's __init__.py

# This is a "factory" that creates session objects.
session_factory = sessionmaker(
    autocommit=False,
    autoflush=False,
)

def get_engine():
    """
    This smart function selects the correct database engine
    based on the user's choice stored in the Flask session.
    It now safely handles being called outside of a request context.
    """
    # Check if we are in an active request context before accessing the session
    if has_request_context():
        db_key = session.get('db_key')
        
        # If the user selected 'personal'
        if db_key == 'personal':
            # Return the engine that is "bound" to the 'personal' key in the config
            return db.get_engine(bind='personal')
    
    # By default, or if the key is 'shared', or if outside a request context,
    # return the main (shared) engine.
    return db.get_engine()

# This is our "magic" session object.
# It will automatically call get_engine() for each request
# to pick the right database connection.
Session = scoped_session(session_factory, scopefunc=get_engine)

