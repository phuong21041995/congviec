/**
 * Handles all logic for the checklist functionality within the task modal.
 */
document.addEventListener('DOMContentLoaded', function () {
    const subtaskListContainer = document.getElementById('subtaskListContainer');
    const newSubtaskInput = document.getElementById('newSubtaskInput');
    const addSubtaskBtn = document.getElementById('addSubtaskBtn');
    const taskForm = document.getElementById('taskForm');
    
    // NEW: Elements for progress bar
    const progressContainer = document.getElementById('checklistProgressContainer');
    const progressText = document.getElementById('checklistProgressText');
    const progressBar = document.getElementById('checklistProgressBar');

    // Guard clause
    if (!subtaskListContainer || !newSubtaskInput || !addSubtaskBtn || !taskForm || !progressContainer) {
        return;
    }

    /**
     * Updates the progress bar and text based on checklist items.
     */
    const updateChecklistProgress = () => {
        const allItems = subtaskListContainer.querySelectorAll('.subtask-item');
        const completedItems = subtaskListContainer.querySelectorAll('.subtask-item input[type="checkbox"]:checked');
        
        const total = allItems.length;
        const completed = completedItems.length;

        if (total === 0) {
            progressContainer.style.display = 'none';
            return;
        }

        progressContainer.style.display = 'block';
        const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;

        progressText.textContent = `${completed}/${total}`;
        progressBar.style.width = `${percentage}%`;
        progressBar.setAttribute('aria-valuenow', percentage);
        // Add text inside progress bar for clarity
        progressBar.textContent = `${percentage}%`;
    };

    /**
     * Renders a single checklist item in the UI.
     * @param {object} subtask - The subtask data object {id, content, is_done}.
     */
    const renderSubtaskItem = (subtask = {}) => {
        const id = subtask.id || `new_${Date.now()}`;
        const content = subtask.content || '';
        const is_done = subtask.is_done || false;

        if (!content) return; 

        const itemWrapper = document.createElement('div');
        itemWrapper.className = 'subtask-item d-flex align-items-center'; 
        if (is_done) {
            itemWrapper.classList.add('done');
        }
        itemWrapper.dataset.id = id;
        itemWrapper.dataset.isNew = String(subtask.id ? false : true);

        itemWrapper.innerHTML = `
            <input class="form-check-input me-2" type="checkbox" ${is_done ? 'checked' : ''}>
            <input type="text" class="form-control form-control-sm border-0 flex-grow-1 bg-transparent" value="${escapeHTML(content)}">
            <button type="button" class="btn btn-sm btn-link text-danger remove-subtask-btn" aria-label="Remove">
                <i class="fa-solid fa-times"></i>
            </button>
        `;
        
        itemWrapper.querySelector('input[type="checkbox"]').addEventListener('change', function() {
            itemWrapper.classList.toggle('done', this.checked);
            updateChecklistProgress();
        });

        subtaskListContainer.appendChild(itemWrapper);
    };

    /**
     * Clears and renders the entire checklist. Exposed globally.
     * @param {Array} subtasks - An array of subtask objects.
     */
    window.renderChecklist = (subtasks = []) => {
        subtaskListContainer.innerHTML = '';
        if (subtasks && subtasks.length > 0) {
            subtasks.forEach(renderSubtaskItem);
        }
        updateChecklistProgress();
    };

    // "Add" button event listener
    addSubtaskBtn.addEventListener('click', () => {
        const content = newSubtaskInput.value.trim();
        if (content) {
            renderSubtaskItem({ content: content, is_done: false });
            newSubtaskInput.value = '';
            newSubtaskInput.focus();
            updateChecklistProgress();
        }
    });

    // Enter key listener
    newSubtaskInput.addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            addSubtaskBtn.click();
        }
    });

    // Remove button listener (delegation)
    subtaskListContainer.addEventListener('click', function(e) {
        const removeBtn = e.target.closest('.remove-subtask-btn');
        if (removeBtn) {
            removeBtn.closest('.subtask-item').remove();
            updateChecklistProgress();
        }
    });

    /**
     * Gathers data from all checklist items for form submission.
     */
    window.prepareSubtasksForSubmission = () => {
        const subtaskItems = subtaskListContainer.querySelectorAll('.subtask-item');
        const subtasksData = [];

        subtaskItems.forEach(itemEl => {
            const id = itemEl.dataset.id;
            const isNew = itemEl.dataset.isNew === 'true';
            const contentInput = itemEl.querySelector('input[type="text"]');
            const isDoneCheckbox = itemEl.querySelector('input[type="checkbox"]');

            if (contentInput && contentInput.value.trim()) {
                subtasksData.push({
                    id: isNew ? null : (isNaN(parseInt(id)) ? null : parseInt(id)),
                    content: contentInput.value.trim(),
                    is_done: isDoneCheckbox.checked
                });
            }
        });

        // START: SỬA LỖI TẠI ĐÂY
        // Thay 'subtasksInput' (viết thường) thành 'subTasksInput' (viết hoa chữ T) để khớp với HTML
        const subtasksInput = document.getElementById('subTasksInput'); 
        // END: SỬA LỖI TẠI ĐÂY

        if (subtasksInput) {
            subtasksInput.value = JSON.stringify(subtasksData);
        } else {
            // Thêm log để dễ dàng debug nếu lỗi vẫn xảy ra
            console.error("CRITICAL ERROR: Could not find the hidden input with ID 'subTasksInput'. Please check '_task_modal.html'.");
        }
    };

    // XSS utility
    function escapeHTML(str) {
        const div = document.createElement('div');
        div.appendChild(document.createTextNode(str));
        return div.innerHTML;
    }
});
