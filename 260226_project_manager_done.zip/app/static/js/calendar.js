/**
 * calendar.js - PHIÊN BẢN FINAL OPTIMIZED (DOM MANIPULATION, NO RELOAD)
 */

(function() {
    if (window.calendarJsInitialized) return;

    // ==========================================================================
    // 1. VARIABLES
    // ==========================================================================
    let taskModal, taskForm;
    let taskModalQueuedFiles = [];
    let lastCreatingCell = null;
    let allOkrData = {}, cachedOkrData = null;

    const SAVE_TASK_URL = window.SAVE_TASK_URL || '/save-task';
    const DELETE_TASK_URL_BASE = window.DELETE_TASK_URL_BASE || '/delete-task/';
    const DELETE_ATTACHMENT_URL_BASE = window.DELETE_ATTACHMENT_URL_BASE || '/delete-uploaded-file/';
    const TASK_API_URL_BASE = '/api/task/';

    // ==========================================================================
    // 2. HELPER FUNCTIONS
    // ==========================================================================
    function formatBytes(bytes, decimals = 2) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024, sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(decimals < 0 ? 0 : decimals)) + ' ' + sizes[i];
    }
    
    function unescapeHTML(str) {
        if (!str) return '';
        const a = document.createElement('textarea');
        a.innerHTML = str;
        return a.value;
    }

    function setSelectColor(selectElement) {
        if (!selectElement) return;
        let type;
        if (selectElement.id === 'taskStatus') type = 'status';
        else if (selectElement.id === 'taskPriority') type = 'priority';
        if (!type) return;

        const colorMap = {
            status: { 'pending': 'status-pending', 'in progress': 'status-in-progress', 'review': 'status-review', 'done': 'status-done', 'drop': 'status-drop' },
            priority: { 'low': 'priority-low', 'medium': 'priority-medium', 'high': 'priority-high', 'urgent': 'priority-urgent' }
        };
        Object.values(colorMap.status).forEach(c => selectElement.classList.remove(c));
        Object.values(colorMap.priority).forEach(c => selectElement.classList.remove(c));
        const valueSlug = selectElement.value.toLowerCase();
        const newClass = colorMap[type][valueSlug];
        if (newClass) selectElement.classList.add(newClass);
    }

    // === NEW: Tạo HTML Element cho task mà không cần Server ===
    function createTaskElementHTML(task) {
        const statusSlug = task.status.toLowerCase().replace(/\s+/g, '-');
        const safeWhat = task.what.replace(/"/g, '&quot;');
        const whoHtml = task.who ? `<span class="text-muted small ms-1 flex-shrink-0" style="font-weight:600; font-size:0.9em; opacity:0.9;">(${task.who})</span>` : '';
        
        const div = document.createElement('div');
        div.className = `timed-task-item status-${statusSlug}`;
        div.setAttribute('data-task-id', task.id);
        div.setAttribute('data-task-json', JSON.stringify(task));
        
        div.innerHTML = `
            <div class="d-flex justify-content-between align-items-center">
                <span class="task-what-truncate" title="${safeWhat}">
                    ${task.what.length > 20 ? safeWhat.substring(0, 20) + '...' : safeWhat}
                </span>
                ${whoHtml}
            </div>
        `;
        return div;
    }

    // ==========================================================================
    // 3. LOGIC FILE UPLOAD
    // ==========================================================================
    function handleTaskModalFiles(files) {
        Array.from(files).forEach(newFile => {
            const exists = taskModalQueuedFiles.some(existing => existing.name === newFile.name && existing.size === newFile.size);
            if (!exists) taskModalQueuedFiles.push(newFile); 
        });
        renderTaskModalQueuedFiles();
    }

	function renderTaskModalQueuedFiles() {
        const listEl = document.getElementById('queuedFilesList');
        if (!listEl) return;
        
        listEl.innerHTML = '';

        // --- SỬA LỖI TẠI ĐÂY ---
        // Nếu không có file thì ẩn đi cho gọn, có file thì PHẢI hiện lên
        if (taskModalQueuedFiles.length === 0) {
            listEl.style.display = 'none';
            return;
        }
        listEl.style.display = 'block'; 
        // -----------------------

        taskModalQueuedFiles.forEach((file, index) => {
            const fileEl = document.createElement('div');
            fileEl.className = 'd-flex justify-content-between align-items-center p-2 mb-1 border rounded bg-white animate__animated animate__fadeIn';
            fileEl.innerHTML = `
                <div class="d-flex align-items-center overflow-hidden">
                    <i class="fa-solid fa-file text-muted me-2"></i>
                    <span class="text-truncate" style="max-width: 200px;">${file.name}</span>
                    <small class="text-muted ms-2">(${formatBytes(file.size)})</small>
                    <span class="badge bg-warning text-dark ms-2" style="font-size: 0.6rem;">Pending</span>
                </div>
                <button type="button" class="btn btn-link text-danger p-0" data-index="${index}"><i class="fa-solid fa-times"></i></button>
            `;
            
            // Event xóa file khỏi hàng đợi
            fileEl.querySelector('button').addEventListener('click', (e) => { 
                e.preventDefault(); 
                taskModalQueuedFiles.splice(index, 1); 
                renderTaskModalQueuedFiles(); 
            });
            
            listEl.appendChild(fileEl);
        });
    }

    function renderTaskModalAttachments(attachments = []) {
        const container = document.getElementById('existing-attachments-list');
        if (!container) return;
        container.innerHTML = '';
        if (!attachments || attachments.length === 0) return;
        
        attachments.forEach(file => {
            const fileEl = document.createElement('div');
            fileEl.className = 'd-flex justify-content-between align-items-center p-2 mb-1 border rounded bg-light';
            fileEl.innerHTML = `
                <div class="d-flex align-items-center overflow-hidden">
                    <i class="fa-solid fa-paperclip text-primary me-2"></i>
                    <a href="${file.url}" target="_blank" class="text-decoration-none text-dark text-truncate small" style="max-width: 200px;">${file.original_filename}</a>
                </div>
                <button type="button" class="btn btn-sm btn-outline-danger border-0 delete-attachment-btn" title="Delete this file"><i class="fa-regular fa-trash-can"></i></button>
            `;
            fileEl.querySelector('.delete-attachment-btn').addEventListener('click', function(e) {
                e.preventDefault();
                if(!confirm('Are you sure you want to delete this file?')) return;
                fetch(DELETE_ATTACHMENT_URL_BASE + file.id, { method: 'POST' })
                    .then(res => res.json())
                    .then(data => { if (data.success) { fileEl.remove(); } else { alert('Failed: ' + data.message); } })
                    .catch(err => console.error(err));
            });
            container.appendChild(fileEl);
        });
    }

    // ==========================================================================
    // 4. LOGIC CHAT / COMMENTS
    // ==========================================================================
    function renderComments(comments) {
        const container = document.getElementById('chatHistory');
        if (!container) return;
        container.innerHTML = '';
        if (!comments || comments.length === 0) {
            container.innerHTML = `<div class="text-center text-muted mt-5 pt-5 opacity-50"><i class="fa-regular fa-comments fa-3x mb-3"></i><p>No comments yet.<br>Start the discussion!</p></div>`;
            return;
        }
        const currentUserId = window.CURRENT_USER_ID; 
        comments.forEach(c => {
            const isMe = (c.user_id === currentUserId);
            const alignClass = isMe ? 'align-items-end' : 'align-items-start';
            const bubbleClass = isMe ? 'chat-bubble-me' : 'chat-bubble-other';
            const userLabel = isMe ? 'You' : c.user_name;
            const deleteHtml = isMe ? `<i class="fa-solid fa-trash ms-2 text-muted opacity-50 hover-opacity-100 delete-comment-btn" style="cursor:pointer; font-size: 0.7rem;" data-id="${c.id}" title="Delete"></i>` : '';
            const html = `
                <div class="d-flex flex-column ${alignClass} mb-3 animate__animated animate__fadeIn">
                    <small class="text-muted mb-1" style="font-size: 0.7rem;">${userLabel} • ${c.time_display}</small>
                    <div class="d-flex align-items-center ${isMe ? 'flex-row-reverse' : ''}">
                        <div class="p-2 px-3 shadow-sm ${bubbleClass}" style="max-width: 85%; word-wrap: break-word;">${c.content}</div>${deleteHtml}
                    </div>
                </div>`;
            container.insertAdjacentHTML('beforeend', html);
        });
        container.querySelectorAll('.delete-comment-btn').forEach(btn => { btn.addEventListener('click', () => deleteComment(btn.dataset.id)); });
        container.scrollTop = container.scrollHeight;
    }

    async function sendComment() {
        const input = document.getElementById('newCommentInput');
        const content = input.value.trim();
        const taskId = document.getElementById('taskId').value;
        const btn = document.getElementById('btnSendComment');
        if (!content || !taskId) return;
        btn.disabled = true; input.disabled = true;
        try {
            const res = await fetch(`/api/task/${taskId}/comment`, { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({ content: content }) });
            const data = await res.json();
            if (data.success) { input.value = ''; await refreshComments(taskId); } else { alert('Error: ' + data.message); }
        } catch (e) { console.error(e); } finally { btn.disabled = false; input.disabled = false; input.focus(); }
    }

    async function deleteComment(commentId) {
        if(!confirm('Delete this comment?')) return;
        try {
            const res = await fetch(`/api/comment/${commentId}`, { method: 'DELETE' });
            const data = await res.json();
            if(data.success) refreshComments(document.getElementById('taskId').value); else alert(data.message);
        } catch(e) { console.error(e); }
    }

    async function refreshComments(taskId) {
        try {
            const response = await fetch(TASK_API_URL_BASE + taskId);
            const data = await response.json();
            if (data.success && data.task) renderComments(data.task.comments);
        } catch (err) { console.error("Refresh comment error:", err); }
    }

    // ==========================================================================
    // 5. FORM HELPERS & MODAL LOGIC
    // ==========================================================================
    function resetTaskForm() {
        if (!taskForm) return;
        taskForm.reset();
        ['taskId', 'taskModalLabel', 'deleteTaskBtn', 'existing-attachments-list', 'queuedFilesList', 'subtaskListContainer', 'taskBuild', 'taskObjective', 'taskKeyResult'].forEach(id => {
            const el = document.getElementById(id);
            if (!el) return;
            if (el.tagName === 'INPUT') el.value = '';
            else if (id === 'taskModalLabel') el.textContent = 'Create New Task';
            else if (id === 'deleteTaskBtn' || id === 'queuedFilesList') el.style.display = 'none';
            else if (id.startsWith('task') && el.tagName === 'SELECT') el.innerHTML = `<option value="">--- ${id.replace('task','')} ---</option>`;
            else el.innerHTML = '';
        });
        taskModalQueuedFiles = [];
        const infoTabBtn = document.querySelector('#taskTabs button[data-bs-target="#details-pane"]');
        if(infoTabBtn) new bootstrap.Tab(infoTabBtn).show();
    }

    async function fetchAllOkrData() {
        if (cachedOkrData) { allOkrData = cachedOkrData; return; }
        if (Object.keys(allOkrData).length > 0) return;
        try {
            const response = await fetch('/api/all-okr-data');
            allOkrData = await response.json(); cachedOkrData = allOkrData;
        } catch (error) { console.error(error); allOkrData = { projects: [], builds: {}, objectives: {}, key_results: {} }; }
    }

    function populateSelect(selectEl, items, selectedId) {
        if (!selectEl) return;
        const placeholder = selectEl.querySelector('option[value=""]');
        selectEl.innerHTML = '';
        if (placeholder) selectEl.appendChild(placeholder);
        (items || []).forEach(item => {
            const option = document.createElement('option');
            option.value = item.id;
            option.textContent = item.name || item.content;
            if (item.id == selectedId) option.selected = true;
            selectEl.appendChild(option);
        });
    }

    async function populateOkrChain(keyResultId) {
        await fetchAllOkrData();
        const kr = allOkrData.key_results[keyResultId];
        const objective = kr ? allOkrData.objectives[kr.objective_id] : null;
        const build = objective ? allOkrData.builds[objective.build_id] : null;
        const project = build ? allOkrData.projects.find(p => p.id == build.project_id) : null;
        populateSelect(document.getElementById('taskProject'), allOkrData.projects || [], project ? project.id : '');
        populateSelect(document.getElementById('taskBuild'), project ? project.builds : [], build ? build.id : '');
        populateSelect(document.getElementById('taskObjective'), build ? Object.values(allOkrData.objectives).filter(o => o.build_id == build.id) : [], objective ? objective.id : '');
        populateSelect(document.getElementById('taskKeyResult'), objective ? objective.key_results : [], keyResultId);
    }

    window.openCreateModal = async function(initialData = {}) {
        resetTaskForm();
        document.getElementById('taskModalLabel').textContent = 'Create New Task';
        document.getElementById('taskDate').value = initialData.date || new Date().toISOString().split('T')[0];
        document.getElementById('taskWho').value = initialData.who_id || window.CURRENT_USER_ID || '';
        if (initialData.hour !== undefined) document.getElementById('taskHour').value = initialData.hour;
        if (initialData.status) document.getElementById('taskStatus').value = initialData.status;
        await populateOkrChain(initialData.key_result_id);
        setSelectColor(document.getElementById('taskStatus'));
        setSelectColor(document.getElementById('taskPriority'));
        renderTaskModalAttachments([]);
        if (window.renderChecklist) window.renderChecklist([]);
        const chatHistory = document.getElementById('chatHistory');
        if(chatHistory) chatHistory.innerHTML = '<div class="text-center text-muted mt-5 pt-5 opacity-50"><p>Save task first to start discussion.</p></div>';
        if (taskModal) taskModal.show();
    };

    window.openEditModal = async function(taskData) {
        resetTaskForm();
        document.getElementById('taskModalLabel').textContent = 'Edit Task';
        document.getElementById('deleteTaskBtn').style.display = 'block';
        document.getElementById('taskId').value = taskData.id || '';
        document.getElementById('taskWhat').value = taskData.what || '';
        if (taskData.task_date) document.getElementById('taskDate').value = taskData.task_date.split('T')[0];
        document.getElementById('taskHour').value = taskData.hour ?? '';
        document.getElementById('taskWho').value = taskData.who_id || '';
        document.getElementById('taskStatus').value = taskData.status || 'Pending';
        document.getElementById('taskPriority').value = taskData.priority || 'Medium';
		document.getElementById('taskNote').value = unescapeHTML(taskData.note || '');
        renderTaskModalAttachments(taskData.attachments);
        if (window.renderChecklist) window.renderChecklist(taskData.sub_tasks || []);
        await populateOkrChain(taskData.key_result_id);
        setSelectColor(document.getElementById('taskStatus'));
        setSelectColor(document.getElementById('taskPriority'));
        renderComments(taskData.comments || []);
        if (taskModal) taskModal.show();
    };

    // ==========================================================================
    // 7. EVENT HANDLERS & SUBMIT
    // ==========================================================================

	function handleCtrlB_Save(event) {
		if (event.ctrlKey && event.key.toLowerCase() === 'b') {
			const taskModalEl = document.getElementById('taskModal');
			if (taskModalEl && taskModalEl.classList.contains('show')) {
				event.preventDefault(); document.getElementById('saveTaskBtn').click();
			}
		}
	}
    
    function handleGlobalClick(event) {
        const taskCard = event.target.closest('.timed-task-item, .kanban-card, .open-task-modal-btn, .task-item-sm');
        const calendarCell = event.target.closest('.task-cell, .allday-cell');
        if (taskCard) {
            event.stopPropagation(); event.preventDefault();
            const taskId = taskCard.dataset.taskId || taskCard.closest('[data-task-id]')?.dataset.taskId;
            if (taskId) {
                fetch(TASK_API_URL_BASE + taskId).then(res => res.json())
                    .then(data => { if (data.success) window.openEditModal(data.task); })
                    .catch(console.error);
            }
        } else if (calendarCell) {
            if (lastCreatingCell) lastCreatingCell.classList.remove('cell-creating');
            calendarCell.classList.add('cell-creating');
            lastCreatingCell = calendarCell;
            const userFilter = document.getElementById('user-filter-select');
            const picId = calendarCell.dataset.userId || (userFilter && userFilter.value !== 'all' ? userFilter.value : (window.CURRENT_USER_ID || ''));
            window.openCreateModal({ date: calendarCell.dataset.date, hour: calendarCell.dataset.hour, who_id: picId });
        }
    }

    function handleFormSubmit(event) {
        event.preventDefault();
        if (taskForm.classList.contains('is-submitting')) return;
        taskForm.classList.add('is-submitting');
        const saveBtn = document.getElementById('saveTaskBtn');
        const originalText = saveBtn.innerHTML;
        saveBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Saving...';
        saveBtn.disabled = true;

        if(window.prepareSubtasksForSubmission) window.prepareSubtasksForSubmission();
        const formData = new FormData(taskForm);
        formData.delete('attachments[]');
        taskModalQueuedFiles.forEach(file => formData.append('attachments[]', file));

        fetch(SAVE_TASK_URL, { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    taskModal.hide();
                    taskModalQueuedFiles = []; 
                    
                    // --- DOM MANIPULATION (NO RELOAD) ---
                    const task = data.task;
                    const existingEls = document.querySelectorAll(`[data-task-id="${task.id}"]`);

                    if (existingEls.length > 0) {
                        // UPDATE EXISTING
                        existingEls.forEach(el => {
                            const titleEl = el.querySelector('.task-what-truncate');
                            if (titleEl) {
                                let displayTitle = task.what;
                                if (displayTitle.length > 20) displayTitle = displayTitle.substring(0, 20) + '...';
                                titleEl.textContent = displayTitle;
                                titleEl.setAttribute('title', task.what);
                            }
                            el.className = el.className.replace(/status-\w+/g, '').trim();
                            el.classList.add(`status-${task.status.toLowerCase().replace(/\s+/g, '-')}`);
                            el.dataset.taskJson = JSON.stringify(task);
                            el.style.backgroundColor = '#d1e7dd';
                            setTimeout(() => el.style.backgroundColor = '', 500);

                            // Check Move (Date/Hour changed)
                            const parentCell = el.closest('.task-cell');
                            if(parentCell) {
                                const cellDate = parentCell.dataset.date;
                                const cellHour = parentCell.dataset.hour || ""; 
                                const taskHourStr = (task.hour === null || task.hour === "") ? "" : String(task.hour);
                                if(cellDate !== task.task_date || cellHour !== taskHourStr) {
                                     el.remove();
                                     const newCell = document.querySelector(`.task-cell[data-date="${task.task_date}"][data-hour="${taskHourStr}"]`);
                                     if(newCell) newCell.appendChild(el);
                                }
                            }
                        });
                    } else {
                        // CREATE NEW
                        const taskHourStr = (task.hour === null || task.hour === undefined) ? "" : String(task.hour);
                        const targetCell = document.querySelector(`.task-cell[data-date="${task.task_date}"][data-hour="${taskHourStr}"]`);
                        if (targetCell) {
                            const newTaskEl = createTaskElementHTML(task);
                            targetCell.appendChild(newTaskEl);
                            newTaskEl.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 400 });
                        }
                    }

                    if(document.getElementById('objectiveDetailModal')?.classList.contains('show')) {
                        document.body.dispatchEvent(new CustomEvent('taskSavedInOkr', { detail: { taskId: task.id, keyResultId: document.getElementById('taskKeyResult').value }}));
                    }
                } else {
                    alert('Error saving task: ' + data.message);
                }
            })
            .catch((err) => { console.error(err); alert('Network error.'); })
            .finally(() => {
                taskForm.classList.remove('is-submitting');
                saveBtn.innerHTML = originalText;
                saveBtn.disabled = false;
            });
    }

    // ==========================================================================
    // 8. INITIALIZE
    // ==========================================================================
    function initialize() {
        const taskModalEl = document.getElementById('taskModal');
        if (!taskModalEl) return;

        taskModal = new bootstrap.Modal(taskModalEl, { backdrop: true, keyboard: true });
        taskForm = document.getElementById('taskForm');

        taskModalEl.addEventListener('hidden.bs.modal', () => {
            document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());
            document.body.classList.remove('modal-open');
            document.body.style.paddingRight = '';
            if (lastCreatingCell) { lastCreatingCell.classList.remove('cell-creating'); lastCreatingCell = null; }
        });

        taskModalEl.addEventListener('shown.bs.modal', () => {
            setSelectColor(document.getElementById('taskStatus'));
            setSelectColor(document.getElementById('taskPriority'));
            
            // Re-bind delete with NO RELOAD logic
            const oldDeleteBtn = document.getElementById('deleteTaskBtn');
            if (oldDeleteBtn) {
                oldDeleteBtn.onclick = null;
                const newDeleteBtn = oldDeleteBtn.cloneNode(true);
                oldDeleteBtn.parentNode.replaceChild(newDeleteBtn, oldDeleteBtn);
                
                newDeleteBtn.addEventListener('click', function() {
                    const taskId = document.getElementById('taskId').value;
                    if (!taskId || !confirm('Delete this task?')) return;
                    
                    const originalText = this.innerHTML;
                    this.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';
                    this.disabled = true;

                    fetch(DELETE_TASK_URL_BASE + taskId, { method: 'POST', headers: { 'Content-Type': 'application/json' }})
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) { 
                            taskModal.hide(); 
                            // DOM Removal
                            document.querySelectorAll(`[data-task-id="${taskId}"]`).forEach(el => {
                                el.style.transition = 'opacity 0.3s';
                                el.style.opacity = '0';
                                setTimeout(() => el.remove(), 300);
                            });
                        } 
                        else { alert(data.message); this.innerHTML = originalText; this.disabled = false; }
                    })
                    .catch(() => window.location.reload());
                });
            }
        });

        document.body.removeEventListener('click', handleGlobalClick);
        document.body.addEventListener('click', handleGlobalClick);
        taskForm.removeEventListener('submit', handleFormSubmit);
        taskForm.addEventListener('submit', handleFormSubmit);
        
        // Attachment logic
        const dropzone = document.getElementById('attachmentDropzone');
        const fileInput = document.getElementById('fileInputTrigger');
        if (dropzone && fileInput) {
            dropzone.addEventListener('click', (e) => { if(e.target === fileInput || e.target.closest('label')) return; fileInput.click(); });
            fileInput.addEventListener('click', (e) => e.stopPropagation());
            fileInput.addEventListener('change', () => { if(fileInput.files.length) { handleTaskModalFiles(fileInput.files); fileInput.value = ''; } });
            ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(evt => dropzone.addEventListener(evt, (e) => { e.preventDefault(); e.stopPropagation(); }, false));
            dropzone.addEventListener('drop', (e) => { if (e.dataTransfer.files.length) handleTaskModalFiles(e.dataTransfer.files); });
            document.addEventListener('paste', (e) => { if (taskModalEl.classList.contains('show') && e.clipboardData.files.length > 0) { e.preventDefault(); handleTaskModalFiles(e.clipboardData.files); } });
        }
        
        // Chat logic
        const btnSend = document.getElementById('btnSendComment');
        const inputComment = document.getElementById('newCommentInput');
        if(btnSend && inputComment) {
            const newBtn = btnSend.cloneNode(true); btnSend.parentNode.replaceChild(newBtn, btnSend); newBtn.addEventListener('click', sendComment);
            const newInput = inputComment.cloneNode(true); inputComment.parentNode.replaceChild(newInput, inputComment); newInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') { e.preventDefault(); sendComment(); }});
        }

        const statusSelect = document.getElementById('taskStatus');
        const prioritySelect = document.getElementById('taskPriority');
        if(statusSelect) statusSelect.addEventListener('change', () => setSelectColor(statusSelect));
        if(prioritySelect) prioritySelect.addEventListener('change', () => setSelectColor(prioritySelect));

        const taskProject = document.getElementById('taskProject');
        const taskBuild = document.getElementById('taskBuild');
        const taskObjective = document.getElementById('taskObjective');
        if (taskProject) taskProject.addEventListener('change', async function() { await fetchAllOkrData(); populateSelect(taskBuild, allOkrData.projects.find(p => p.id == this.value)?.builds || []); });
        if (taskBuild) taskBuild.addEventListener('change', async function() { await fetchAllOkrData(); populateSelect(taskObjective, Object.values(allOkrData.objectives).filter(o => o.build_id == this.value)); });
        if (taskObjective) taskObjective.addEventListener('change', async function() { await fetchAllOkrData(); populateSelect(document.getElementById('taskKeyResult'), allOkrData.objectives[this.value]?.key_results || []); });

        const recurrenceSelect = document.getElementById('taskRecurrence');
        const endGroup = document.getElementById('recurrenceEndGroup');
        const endDateInput = document.getElementById('taskRecurrenceEndDate');
        if (recurrenceSelect && endGroup) {
            recurrenceSelect.addEventListener('change', function() {
                if (this.value !== 'none') { endGroup.style.display = 'block'; if(endDateInput) endDateInput.setAttribute('required', 'required'); } 
                else { endGroup.style.display = 'none'; if(endDateInput) { endDateInput.removeAttribute('required'); endDateInput.value = ''; } }
            });
        }

        setTimeout(() => {
            const calendarContainer = document.querySelector('.calendar-grid-container');
            if (calendarContainer && typeof Sortable !== 'undefined') {
                document.querySelectorAll('.task-cell, .allday-cell').forEach(cell => {
                    new Sortable(cell, {
                        group: 'shared-tasks', animation: 150,
                        ghostClass: 'sortable-ghost', chosenClass: 'sortable-chosen',
                        onEnd: function (evt) {
                            const taskElement = evt.item;
                            const targetCell = evt.to;
                            const originalTaskData = JSON.parse(taskElement.dataset.taskJson);
                            const newDate = targetCell.dataset.date;
                            const newHour = targetCell.dataset.hour;
                            if (newDate === originalTaskData.task_date && newHour == originalTaskData.hour) return;

                            fetch('/api/update-task-dnd', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({
                                    taskId: originalTaskData.id, task_date: newDate, hour: (newHour) ? newHour : null, who_id: originalTaskData.who_id
                                }),
                            })
                            .then(r => r.json())
                            .then(d => {
                                if(d.success) {
                                    originalTaskData.task_date = newDate;
                                    originalTaskData.hour = newHour ? parseInt(newHour) : null;
                                    taskElement.dataset.taskJson = JSON.stringify(originalTaskData);
                                    if(typeof showToast === 'function') showToast('Success', 'Moved', 'success');
                                } else { evt.from.appendChild(taskElement); alert(d.message); }
                            })
                            .catch(() => { evt.from.appendChild(taskElement); });
                        }
                    });
                });
            }
        }, 100);
    }

    document.addEventListener('DOMContentLoaded', initialize);
	document.removeEventListener('keydown', handleCtrlB_Save);
    document.addEventListener('keydown', handleCtrlB_Save);
    window.calendarJsInitialized = true;
})();