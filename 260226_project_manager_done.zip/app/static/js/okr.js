// 1. CHỐT CHẶN CHỐNG CHẠY KÉP
if (window.okrJsInitialized) {
    console.warn('okr.js đã được load trước đó. Bỏ qua lần load này.');
} else {
    window.okrJsInitialized = true;

    document.addEventListener('DOMContentLoaded', function () {
        const okrTabContent = document.getElementById('okr-tab-content');
        if (!okrTabContent) return;

        const objectiveDetailModalEl = document.getElementById('objectiveDetailModal');
        const objectiveDetailModal = objectiveDetailModalEl ? new bootstrap.Modal(objectiveDetailModalEl) : null;

        // ========================================================
        // FIX LỖI MODAL (Z-INDEX & BACKDROP & SCROLL) - PHIÊN BẢN FIX MẠNH
        // ========================================================
        
        // 1. Khi MỞ modal: Đẩy z-index lên cao
        document.addEventListener('show.bs.modal', function (event) {
            const zIndexBase = 1050; 
            const visibleModals = document.querySelectorAll('.modal.show');
            
            // Nếu đang có modal khác mở, modal mới phải nằm cao hơn
            if (visibleModals.length > 0) {
                const nextZIndex = zIndexBase + (10 * (visibleModals.length + 1));
                event.target.style.zIndex = nextZIndex;
                
                // Đẩy backdrop mới nhất xuống ngay dưới modal này
                setTimeout(() => {
                    const backdrops = document.querySelectorAll('.modal-backdrop');
                    if (backdrops.length > 0) {
                        const lastBackdrop = backdrops[backdrops.length - 1];
                        lastBackdrop.style.zIndex = nextZIndex - 5;
                    }
                }, 0);
            }
        });

        // 2. [QUAN TRỌNG] Khi ĐÓNG modal: Xử lý dọn dẹp
        document.addEventListener('hidden.bs.modal', function (event) {
            const visibleModals = document.querySelectorAll('.modal.show');
            
            // CASE A: Vẫn còn modal khác đang mở (ví dụ đóng Task, còn OKR)
            if (visibleModals.length > 0) {
                // Ép body giữ trạng thái modal-open để không bị vỡ layout
                document.body.classList.add('modal-open');

                // Nếu mất nền đen thì tạo lại
                if (!document.querySelector('.modal-backdrop')) {
                    const newBackdrop = document.createElement('div');
                    newBackdrop.className = 'modal-backdrop fade show';
                    document.body.appendChild(newBackdrop);
                }
            } 
            // CASE B: Đã đóng hết tất cả modal
            else {
                // 1. Mở khóa scroll cho body
                document.body.classList.remove('modal-open');
                document.body.style.overflow = '';
                document.body.style.paddingRight = '';

                // 2. XÓA SẠCH mọi backdrop còn sót lại (kể cả do code tạo ra)
                const backdrops = document.querySelectorAll('.modal-backdrop');
                backdrops.forEach(bd => bd.remove());

                // 3. Reset z-index của modal vừa đóng để lần sau mở lại bình thường
                event.target.style.zIndex = '';
            }
        });
        
        // ========================================================
        // LOGIC CHO BOARD CHÍNH
        // ========================================================

        const boardContainer = document.getElementById('okr-board');
        if(boardContainer) {
            boardContainer.addEventListener('click', function(event) {
                const target = event.target;
                const projectId = boardContainer.dataset.projectId;

                // Helper: Xử lý UI form (Toggle hiển thị)
                const handleForm = (wrapperSelector, openBtnClass, formClass, focusElement = 'textarea') => {
                    const wrapper = target.closest(wrapperSelector);
                    if (!wrapper) return false;
                    
                    const openBtn = wrapper.querySelector(openBtnClass);
                    const form = wrapper.querySelector(formClass);
                    
                    if (target.matches(openBtnClass) || target.closest(openBtnClass)) {
                        openBtn.style.display = 'none';
                        form.style.display = 'block';
                        form.querySelector(focusElement).focus();
                        return true;
                    }
                    if (target.matches('.cancel-add-card-btn, .cancel-add-list-btn') || target.closest('.cancel-add-card-btn, .cancel-add-list-btn')) {
                        form.style.display = 'none';
                        openBtn.style.display = 'block';
                        form.querySelector(focusElement).value = '';
                        return true;
                    }
                    return false;
                };

                // Xử lý các nút mở/đóng form
                if (handleForm('.trello-list-footer', '.add-card-btn', '.add-card-form')) return;

                // A. XỬ LÝ SAVE CARD (Thêm Objective)
                const saveCardBtn = target.closest('.save-card-btn');
                if (saveCardBtn) {
                    if (saveCardBtn.disabled) return;

                    const footer = saveCardBtn.closest('.trello-list-footer');
                    const textarea = footer.querySelector('textarea');
                    const content = textarea.value.trim();
                    const buildId = saveCardBtn.closest('.trello-list').dataset.buildId;

                    if (content) {
                        saveCardBtn.disabled = true;
                        const originalText = saveCardBtn.innerHTML;
                        saveCardBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Saving...';

                        saveNewObjective({ content, build_id: buildId, project_id: projectId }, footer)
                            .finally(() => {
                                if (saveCardBtn) {
                                    saveCardBtn.disabled = false;
                                    saveCardBtn.innerHTML = originalText;
                                }
                            });
                    } else {
                        textarea.focus();
                    }
                    return; 
                }

                // B. XỬ LÝ MỞ MODAL CHI TIẾT
                const cardElement = target.closest('.trello-card');
                if (cardElement) {
                    openObjectiveDetailModal(cardElement.dataset.objId);
                }
            });
        }

        // ========================================================
        // LOGIC CHO MODAL CHI TIẾT OBJECTIVE
        // ========================================================
        if (objectiveDetailModalEl) {
            let currentEditingElement = null;
            
            function getModalData() {
                try {
                    return JSON.parse(objectiveDetailModalEl.dataset.objectiveData);
                } catch (e) {
                    return null;
                }
            }

            // --- CÁC HÀM RENDER ---
            
            function renderKrNavItem(kr) {
                let doneTasks = 0;
                let totalTasks = 0;
                if (kr.tasks && Array.isArray(kr.tasks)) {
                    totalTasks = kr.tasks.length;
                    doneTasks = kr.tasks.filter(t => t.status === 'Done').length;
                }

                return `
                <a href="#" class="kr-nav-item" data-kr-id="${kr.id}">
                    <span class="kr-nav-title">${kr.content}</span>
                    <span class="kr-nav-count" id="kr-badge-${kr.id}">${doneTasks}/${totalTasks}</span>
                </a>`;
            }

            function renderTaskHtml(task) {
                let taskDateHtml = '';
                if (task.task_date) {
                    try {
                        const date = new Date(task.task_date + 'T00:00:00'); 
                        const day = String(date.getDate()).padStart(2, '0');
                        const month = String(date.getMonth() + 1).padStart(2, '0');
                        taskDateHtml = `<span class="badge bg-light text-dark border task-date-badge">${day}/${month}</span>`;
                    } catch(e) {}
                }

                return `
                <div class="kr-task-item ${task.status === 'Done' ? 'task-done' : ''}">
                    <input class="form-check-input task-checkbox-detail me-2" type="checkbox" id="detail-task-${task.id}" data-task-id="${task.id}" ${task.status === 'Done' ? 'checked' : ''}>
                    <span class="task-link-in-modal" data-task-id="${task.id}" role="button">${task.what}</span>
                    <div class="kr-task-meta">
                        ${task.assignee ? `<span class="badge bg-light text-dark border task-assignee-badge">${task.assignee.username}</span>` : ''}
                        ${taskDateHtml}
                    </div>
                </div>`;
            }
            
            function renderKrTasks(krId) {
                const objectiveData = getModalData();
                if (!objectiveData) return;
                
                const kr = objectiveData.key_results.find(k => k.id == krId);
                if (!kr) return;

                const headerContainer = document.getElementById('taskPaneHeader');
                const taskContainer = document.getElementById('krTaskContainer');
                const addButtonContainer = document.getElementById('krAddTaskButtonContainer');

                // Render Header
                headerContainer.innerHTML = `
                    <button class="btn btn-sm delete-kr-btn" data-kr-id="${kr.id}" title="Delete Key Result"><i class="fa-solid fa-trash-can"></i></button>
                    <div class="editable w-100" data-field="content" data-item-type="key_result">
                        <div class="d-flex align-items-center">
                            <i class="fa-solid fa-flag text-success me-2"></i>
                            <strong class="text-dark editable-text fs-5">${kr.content}</strong>
                        </div>
                        <input type="text" class="form-control form-control-sm editable-input">
                    </div>
                    <div class="d-flex align-items-center gap-3 mt-3">
                        <input type="date" class="form-control form-control-sm kr-date-input" data-field="start_date" value="${kr.start_date || ''}" title="KR Start Date">
                        <span class="text-muted">→</span>
                        <input type="date" class="form-control form-control-sm kr-date-input" data-field="end_date" value="${kr.end_date || ''}" title="KR End Date">
                    </div>
                `;
                
                // Render Task List
                if (kr.tasks && kr.tasks.length > 0) {
                    taskContainer.innerHTML = kr.tasks.map(renderTaskHtml).join('');
                } else {
                    taskContainer.innerHTML = `<p class="text-muted small">No tasks yet for this Key Result.</p>`;
                }

                // Render Add Button
                addButtonContainer.innerHTML = `<button class="btn btn-sm btn-light border add-task-in-detail-btn" data-kr-id="${kr.id}"><i class="fa-solid fa-plus"></i> Add a task...</button>`;
                
                // Active Nav
                document.querySelectorAll('#objectiveKrListNav .kr-nav-item').forEach(item => {
                    item.classList.toggle('active', item.dataset.krId == krId);
                });
            }

            // --- EDITING LOGIC ---
            
            const startEditing = (editableContainer) => {
                if (currentEditingElement) cancelEditing();
                currentEditingElement = editableContainer;
                editableContainer.classList.add('editing');
                const input = editableContainer.querySelector('.editable-input');
                const textEl = editableContainer.querySelector('.editable-text');
                input.value = textEl.textContent.trim();
                input.focus();
                input.select();
            };

            const cancelEditing = () => {
                if (!currentEditingElement) return;
                currentEditingElement.classList.remove('editing');
                currentEditingElement = null;
            };
            
            const saveEditing = async () => {
                if (!currentEditingElement) return;
                const editableContainer = currentEditingElement;
                const field = editableContainer.dataset.field;
                const itemType = editableContainer.dataset.itemType;
                
                const itemId = (itemType === 'objective') 
                    ? objectiveDetailModalEl.dataset.objectiveId
                    : editableContainer.closest('[data-kr-id]')?.dataset.krId || document.querySelector('.kr-nav-item.active')?.dataset.krId;
                    
                if (!itemId) { cancelEditing(); return; }
                    
                const value = editableContainer.querySelector('.editable-input').value.trim();
                const textElement = editableContainer.querySelector('.editable-text');

                if (value === textElement.textContent.trim()) { cancelEditing(); return; }

                await updateItem(itemType, itemId, { [field]: value }, () => {
                    textElement.textContent = value;
                    editableContainer.classList.remove('editing');
                    currentEditingElement = null;
                    
                    if (itemType === 'objective' && field === 'content') {
                        const cardTitle = document.querySelector(`.trello-card[data-obj-id="${itemId}"] .card-title`);
                        if(cardTitle) cardTitle.textContent = value;
                    }
                    else if (itemType === 'key_result' && field === 'content') {
                        const navItem = document.querySelector(`.kr-nav-item[data-kr-id="${itemId}"] .kr-nav-title`);
                        if(navItem) navItem.textContent = value;
                        
                        let objectiveData = getModalData();
                        if (objectiveData && objectiveData.key_results) {
                            const kr = objectiveData.key_results.find(k => k.id == itemId);
                            if(kr) kr.content = value;
                            objectiveDetailModalEl.dataset.objectiveData = JSON.stringify(objectiveData);
                        }
                    }
                });
            };

            // --- EVENT LISTENERS MODAL ---

            objectiveDetailModalEl.addEventListener('click', async (event) => {
                const target = event.target;
                
                if (objectiveDetailModalEl.classList.contains('modal-loading') || objectiveDetailModalEl.classList.contains('modal-error')) {
                    return;
                }

                // 1. Nav Item
                const krNavItem = target.closest('.kr-nav-item');
                if (krNavItem) {
                    event.preventDefault();
                    renderKrTasks(krNavItem.dataset.krId);
                    return;
                }

                // 2. Editable Text
                const editableText = target.closest('.editable-text');
                if (editableText) {
                    startEditing(editableText.closest('.editable'));
                    return;
                }
                
                // 3. Open Form KR
                if(target.closest('.add-kr-btn')) {
                    const wrapper = document.getElementById('add-kr-form-wrapper');
                    wrapper.querySelector('.add-kr-form').style.display = 'block';
                    wrapper.querySelector('textarea').focus();
                    return;
                }

                // 4. Cancel Form KR
                if (target.matches('.cancel-add-kr-btn') || target.closest('.cancel-add-kr-btn')) {
                    const wrapper = document.getElementById('add-kr-form-wrapper');
                    wrapper.querySelector('textarea').value = '';
                    wrapper.querySelector('.add-kr-form').style.display = 'none';
                    return;
                } 
                
                // 5. Save KR (FIX DOUBLE CLICK)
                const saveKrBtn = target.closest('.save-kr-btn');
                if (saveKrBtn) {
                    if (saveKrBtn.disabled) return;

                    const wrapper = document.getElementById('add-kr-form-wrapper');
                    const textarea = wrapper.querySelector('textarea');
                    const content = textarea.value.trim();
                    const objectiveId = objectiveDetailModalEl.dataset.objectiveId;
                    
                    if(content && objectiveId) {
                        saveKrBtn.disabled = true;
                        const originalHtml = saveKrBtn.innerHTML;
                        saveKrBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';

                        try {
                            const newKr = await saveNewKeyResult({ content, objective_id: objectiveId });
                            if(newKr) {
                                await openObjectiveDetailModal(objectiveId); 
                            }
                        } catch(e) {
                            console.error(e);
                            showToast?.('Error', e.message, 'danger');
                        } finally {
                            if (document.body.contains(saveKrBtn)) {
                                saveKrBtn.disabled = false;
                                saveKrBtn.innerHTML = originalHtml;
                            }
                        }
                    }
                    return;
                }

                // 6. Add Task Modal
                if (target.matches('.add-task-in-detail-btn') || target.closest('.add-task-in-detail-btn')) {
                    const krId = target.dataset.krId || target.closest('.add-task-in-detail-btn').dataset.krId;
                    if (window.openCreateModal) window.openCreateModal({ key_result_id: krId });
                    return;
                }

                // 7. Delete KR
                const deleteKrBtn = target.closest('.delete-kr-btn');
                if(deleteKrBtn) {
                    const krId = deleteKrBtn.dataset.krId;
                    const objectiveId = objectiveDetailModalEl.dataset.objectiveId;
                    if (krId && objectiveId && confirm('Delete this Key Result?')) {
                        await deleteItem('key_result', krId, () => {
                            openObjectiveDetailModal(objectiveId); 
                        });
                    }
                    return;
                }

                // 8. Delete Objective
                if(target.matches('#objectiveDetailDeleteBtn') || target.closest('#objectiveDetailDeleteBtn')) {
                    const objectiveId = objectiveDetailModalEl.dataset.objectiveId; 
                    if(objectiveId && confirm('Delete this Objective?')) {
                        await deleteItem('objective', objectiveId, () => { 
                            document.querySelector(`.trello-card[data-obj-id="${objectiveId}"]`)?.remove(); 
                            objectiveDetailModal.hide();
                        });
                    }
                    return;
                }

                // 9. Open Task Edit
                const taskLink = target.closest('.task-link-in-modal');
                if (taskLink) {
                    const taskId = taskLink.dataset.taskId;
                    if (taskId && window.openEditModal) { 
                        try {
                            const data = await fetchApi(`/api/task/${taskId}`);
                            if (data.success) { window.openEditModal(data.task); }
                        } catch (error) { console.error(error); }
                    }
                }
            });
            
            // Keydown (Enter/Esc)
            objectiveDetailModalEl.addEventListener('keydown', (event) => {
                if (!currentEditingElement) return;
                if (event.key === 'Enter' && currentEditingElement.querySelector('input[type="text"]')) {
                    event.preventDefault();
                    saveEditing();
                } else if (event.key === 'Escape') {
                    cancelEditing();
                }
            });

            // Focusout
            objectiveDetailModalEl.addEventListener('focusout', (event) => {
                if (currentEditingElement && !currentEditingElement.contains(event.relatedTarget)) {
                    saveEditing();
                }
            });
            
            // Checkbox & Date Change
            objectiveDetailModalEl.addEventListener('change', async (event) => {
                // Checkbox
                if (event.target.matches('.task-checkbox-detail')) {
                    const isChecked = event.target.checked;
                    const taskId = event.target.dataset.taskId;
                    
                    const data = await updateItem('task', taskId, { status: isChecked ? 'Done' : 'Pending' });
                    
                    const label = event.target.closest('.kr-task-item');
                    if (label) label.classList.toggle('task-done', isChecked);
                    
                    let objectiveData = getModalData();
                    if (data && data.kr_id && objectiveData) {
                        const kr = objectiveData.key_results.find(k => k.id == data.kr_id);
                        if(kr) {
                            kr.tasks = kr.tasks || [];
                            const task = kr.tasks.find(t => t.id == taskId);
                            if(task) task.status = isChecked ? 'Done' : 'Pending';
                            else { openObjectiveDetailModal(objectiveDetailModalEl.dataset.objectiveId); return; }
                            
                            const totalTasksInKr = kr.tasks.length;
                            const doneTasksInKr = kr.tasks.filter(t => t.status === 'Done').length;
                            kr.current = doneTasksInKr;
                            kr.target = totalTasksInKr;
                            
                            objectiveDetailModalEl.dataset.objectiveData = JSON.stringify(objectiveData);
                            const krBadge = document.getElementById(`kr-badge-${data.kr_id}`);
                            if(krBadge) krBadge.textContent = `${doneTasksInKr}/${totalTasksInKr}`;
                            updateProgressUI(data.objective_id, objectiveData); 
                        }
                    }
                }
                // Date Input
                else if (event.target.matches('.objective-date-input, .kr-date-input')) {
                    const field = event.target.dataset.field;
                    const value = event.target.value; 
                    const itemType = event.target.matches('.objective-date-input') ? 'objective' : 'key_result';
                    
                    const itemId = (itemType === 'objective') 
                        ? objectiveDetailModalEl.dataset.objectiveId
                        : document.querySelector('.kr-nav-item.active')?.dataset.krId;
                    
                    if(itemId) {
                        await updateItem(itemType, itemId, { [field]: value });
                        let objectiveData = getModalData();
                        if (objectiveData) {
                            if (itemType === 'objective') objectiveData[field] = value;
                            else if (itemType === 'key_result' && objectiveData.key_results) {
                                const kr = objectiveData.key_results.find(k => k.id == itemId);
                                if (kr) kr[field] = value;
                            }
                            objectiveDetailModalEl.dataset.objectiveData = JSON.stringify(objectiveData);
                        }
                    }
                }
            });

            // Listener refresh
            document.body.addEventListener('taskSavedInOkr', function(e) {
                const currentObjectiveId = objectiveDetailModalEl.dataset.objectiveId;
                if (currentObjectiveId) {
                    const activeKrId = document.querySelector('.kr-nav-item.active')?.dataset.krId;
                    openObjectiveDetailModal(currentObjectiveId, activeKrId); 
                }
            });
        }

        // ========================================================
        // HELPERS
        // ========================================================
        
        async function saveNewObjective(payload, formFooter) {
            try {
                const data = await fetchApi('/api/objective/add', { method: 'POST', body: JSON.stringify(payload) });
                const cardContainer = formFooter.previousElementSibling;
                // Check dup before insert
                if (!cardContainer.querySelector(`.trello-card[data-obj-id="${data.objective.id}"]`)) {
                    cardContainer.insertAdjacentHTML('beforeend', `
                        <div class="trello-card" data-obj-id="${data.objective.id}">
                            <div class="card-title">${data.objective.content}</div>
                            <div class="card-summary">
                                <i class="fa-solid fa-list-check"></i>
                                <div class="progress"><div class="progress-bar" style="width: 0%;"></div></div>
                                <span>0/0</span>
                            </div>
                        </div>
                    `);
                }
                formFooter.querySelector('textarea').value = '';
                formFooter.querySelector('.cancel-add-card-btn').click();
                return data;
            } catch (error) { 
                showToast?.('Error', error.message, 'danger'); 
                throw error;
            }
        }
        
        async function saveNewKeyResult(payload) {
            try {
                const data = await fetchApi('/add-key-result', { method: 'POST', body: JSON.stringify(payload) });
                showToast?.('Success', 'Key Result added.', 'success');
                return data.kr;
            } catch(error) { 
                showToast?.('Error', error.message, 'danger'); 
                throw error;
            }
        }

        async function updateItem(itemType, itemId, payload, onSuccess) {
            try {
                const data = await fetchApi(`/api/update/${itemType}/${itemId}`, { method: 'POST', body: JSON.stringify(payload) });
                if (onSuccess) onSuccess();
                showToast?.('Success', `${itemType} updated.`, 'success');
                return data;
            } catch (error) {
                showToast?.('Error', `Could not update: ${error.message}`, 'danger');
                return null;
            }
        }
        
        async function deleteItem(itemType, itemId, onSuccess) {
            try {
                const response = await fetch(`/delete/${itemType}/${itemId}`, { 
                    method: 'POST', 
                    headers: { 'Content-Type': 'application/json' }
                });
                if (response.ok || response.status === 404) {
                    if (onSuccess) onSuccess();
                    showToast?.('Success', `${itemType} deleted.`, 'success');
                } else {
                    const data = await response.json();
                    throw new Error(data.message || 'Cannot delete');
                }
            } catch (error) {
                showToast?.('Error', error.message, 'danger');
            }
        }
        
        function updateProgressUI(objectiveId, objectiveData) {
            const mainCard = document.querySelector(`.trello-card[data-obj-id="${objectiveId}"]`);
            if(mainCard && objectiveData) { 
                let totalDone = 0;
                let totalTasks = 0;
                objectiveData.key_results.forEach(kr => {
                    if (kr.tasks) {
                        totalTasks += kr.tasks.length;
                        totalDone += kr.tasks.filter(t => t.status === 'Done').length;
                    }
                });
                const overallProgress = totalTasks > 0 ? (totalDone * 100 / totalTasks) : 0;
                mainCard.querySelector('.progress-bar').style.width = `${overallProgress}%`;
                mainCard.querySelector('.card-summary span').textContent = `${totalDone}/${totalTasks}`;
            }
        }
        
        async function openObjectiveDetailModal(objId, activeKrId = null) { 
            if (!objectiveDetailModal) return;
            objectiveDetailModalEl.dataset.objectiveId = objId;
            objectiveDetailModalEl.classList.add('modal-loading');
            objectiveDetailModalEl.classList.remove('modal-error'); 
            
            const modalTitle = document.getElementById('objectiveDetailTitle');
            const descriptionContainer = document.getElementById('objectiveDetailDescription');
            const krNavContainer = document.getElementById('objectiveKrListNav');
            const taskHeaderContainer = document.getElementById('taskPaneHeader');
            const taskListContainer = document.getElementById('krTaskContainer');
            const taskAddBtnContainer = document.getElementById('krAddTaskButtonContainer');

            // Reset UI
            modalTitle.textContent = 'Loading...';
            descriptionContainer.innerHTML = '<p class="m-0">Loading...</p>';
            krNavContainer.innerHTML = '<div class="text-center p-3"><div class="spinner-border text-primary spinner-sm"></div></div>';
            taskHeaderContainer.innerHTML = '<h6 class="text-muted">Select a Key Result...</h6>';
            taskListContainer.innerHTML = '';
            taskAddBtnContainer.innerHTML = '';
            
            if (!objectiveDetailModalEl.classList.contains('show')) objectiveDetailModal.show();

            try {
                const data = await fetchApi(`/api/objective/${objId}/details`);
                if (!data.objective) throw new Error("No data");
                
                objectiveDetailModalEl.dataset.objectiveData = JSON.stringify(data.objective);
                const objective = data.objective; 

                modalTitle.textContent = objective.content;
                descriptionContainer.innerHTML = objective.note 
                    ? `<p class="m-0">${objective.note.replace(/\n/g, '<br>')}</p>` 
                    : '<p class="m-0 text-muted">Add description...</p>';
                
                objectiveDetailModalEl.querySelector('.objective-date-input[data-field="start_date"]').value = objective.start_date || '';
                objectiveDetailModalEl.querySelector('.objective-date-input[data-field="end_date"]').value = objective.end_date || '';

                if (objective.key_results && objective.key_results.length > 0) {
                    krNavContainer.innerHTML = objective.key_results.map(renderKrNavItem).join('');
                    let krToActivate = activeKrId || objective.key_results[0].id;
                    if (!objective.key_results.find(kr => kr.id == krToActivate)) krToActivate = objective.key_results[0].id;
                    renderKrTasks(krToActivate); 
                } else {
                    krNavContainer.innerHTML = '<p class="text-muted small">No Key Results yet.</p>';
                }
                updateProgressUI(objId, objective);

            } catch (error) {
                console.error(error);
                modalTitle.textContent = 'Error';
                krNavContainer.innerHTML = `<div class="alert alert-danger">${error.message}</div>`;
                objectiveDetailModalEl.classList.add('modal-error'); 
            } finally {
                objectiveDetailModalEl.classList.remove('modal-loading');
            }
        }

        async function fetchApi(url, options = {}) {
            options.headers = { ...options.headers, 'Content-Type': 'application/json' };
            const response = await fetch(url, options);
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.message || `Server error: ${response.status}`);
            }
            const data = await response.json();
            if (data.success === false) throw new Error(data.message || 'Error');
            return data;
        }
    });
}