/**
 * File này chứa các script chung cho toàn bộ ứng dụng,
 * đã được tách ra từ base.html
 */

// Kích hoạt Tooltip của Bootstrap
const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
[...tooltipTriggerList].forEach(el => new bootstrap.Tooltip(el));

/**
 * Hiển thị một thông báo toast.
 * @param {string} title - Tiêu đề của toast.
 * @param {string} message - Nội dung thông báo.
 * @param {string} type - Loại toast ('info', 'success', 'warning', 'danger').
 * @param {number} delay - Thời gian hiển thị (ms).
 */
function showToast(title, message, type = 'info', delay = 5000) {
    const toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) return;

    const toastId = 'toast-' + Date.now();
    const toastTypeClasses = {
        success: { bg: 'bg-success-subtle', icon: 'fa-solid fa-circle-check text-success' },
        danger:  { bg: 'bg-danger-subtle', icon: 'fa-solid fa-triangle-exclamation text-danger' },
        warning: { bg: 'bg-warning-subtle', icon: 'fa-solid fa-circle-exclamation text-warning' },
        info:    { bg: 'bg-info-subtle', icon: 'fa-solid fa-circle-info text-info' }
    };
    const toastInfo = toastTypeClasses[type] || toastTypeClasses['info'];

    const toastHTML = `
        <div id="${toastId}" class="toast ${toastInfo.bg}" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="${delay}">
            <div class="toast-header">
                <i class="${toastInfo.icon} me-2"></i>
                <strong class="me-auto">${title}</strong>
                <small>Vừa xong</small>
                <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">${message}</div>
        </div>
    `;

    toastContainer.insertAdjacentHTML('beforeend', toastHTML);
    const toastElement = document.getElementById(toastId);
    const toast = new bootstrap.Toast(toastElement);
    toastElement.addEventListener('hidden.bs.toast', () => toastElement.remove());
    toast.show();
}

// Logic để lọc các project ở sidebar
document.addEventListener('DOMContentLoaded', () => {
    const switchEl = document.getElementById('sidebarShowDoneProjectsSwitch');
    const projectList = document.getElementById('sidebar-project-list');
    const LS_KEY = 'sidebarShowDone';

    if (!switchEl || !projectList) return;

    const applyFilter = () => {
        const showDone = switchEl.checked;
        projectList.querySelectorAll('li.nav-item').forEach(item => {
            if (showDone || item.dataset.status !== 'Done') {
                item.style.display = '';
            } else {
                item.style.display = 'none';
            }
        });
    };

    switchEl.addEventListener('change', () => {
        localStorage.setItem(LS_KEY, switchEl.checked);
        applyFilter();
    });

    // Load trạng thái ban đầu từ localStorage
    const savedState = localStorage.getItem(LS_KEY);
    switchEl.checked = savedState === 'true'; 
    applyFilter();
});
