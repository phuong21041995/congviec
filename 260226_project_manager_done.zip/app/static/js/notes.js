document.addEventListener('DOMContentLoaded', function() {
    const board = document.getElementById('notes-board');
    if (!board) return;

    // --- 1. QUẢN LÝ EDITOR & MODAL ---
    let toastEditor = null;         
    let currentEditorContent = "";  

    const editNoteModalEl = document.getElementById('editNoteModal');
    // Init Modal với backdrop static
    const editNoteModal = new bootstrap.Modal(editNoteModalEl, {
        backdrop: 'static', 
        keyboard: false
    });

    // Timing Hack: Đợi Modal hiện hẳn mới tạo Editor để tránh lỗi layout
    editNoteModalEl.addEventListener('shown.bs.modal', function () {
        setTimeout(() => {
            if (toastEditor) {
                try { toastEditor.destroy(); } catch(e) {}
                toastEditor = null;
            }

            toastEditor = new toastui.Editor({
                el: document.querySelector('#toastui-editor'),
                height: '100%',
                initialEditType: 'markdown',
                previewStyle: 'vertical',
                initialValue: currentEditorContent, 
                placeholder: 'Ghi chú cuộc họp, ý tưởng... (Dùng - [ ] để tạo task)',
                usageStatistics: false,
                autofocus: false,
                toolbarItems: [
                    ['heading', 'bold', 'italic', 'strike'],
                    ['hr', 'quote'],
                    ['ul', 'ol', 'task', 'indent', 'outdent'],
                    ['table', 'image', 'link'],
                    ['code', 'codeblock']
                ]
            });

            // Gán biến editor ra window để nút "Phân tích" bên ngoài gọi được
            window.editor = toastEditor; 

        }, 50);
    });

    // Destroy editor khi đóng modal để giải phóng bộ nhớ
    editNoteModalEl.addEventListener('hide.bs.modal', function () {
        if (toastEditor) {
            try { toastEditor.destroy(); } catch(e) {}
            toastEditor = null;
        }
        window.editor = null; 

        document.getElementById('editNoteTitle').value = "";
        document.getElementById('edit-note-attachment-list').innerHTML = "";
        document.getElementById('edit-note-attachments').value = "";
        document.getElementById('linked-task-list').innerHTML = ""; 
        currentEditorContent = ""; 
    });

    // --- 2. HÀM RENDER LINKED TASKS TRONG MODAL ---
    function renderLinkedTasksInModal(tasks) {
        const container = document.getElementById('linked-task-list');
        const countBadge = document.getElementById('linked-task-count');
        
        container.innerHTML = '';
        if (!tasks || tasks.length === 0) {
            countBadge.innerText = '0';
            countBadge.className = 'badge bg-secondary rounded-pill';
            container.innerHTML = '<div class="text-muted fst-italic p-2 text-center small">Chưa có công việc nào được liên kết.</div>';
            return;
        }

        const pendingTasks = tasks.filter(t => t.status !== 'Done');
        const doneTasks = tasks.filter(t => t.status === 'Done');
        const sortedTasks = [...pendingTasks, ...doneTasks];

        countBadge.innerText = `${doneTasks.length}/${tasks.length}`;
        countBadge.className = doneTasks.length === tasks.length ? 'badge bg-success rounded-pill' : 'badge bg-primary rounded-pill';

        sortedTasks.forEach(task => {
            const isDone = task.status === 'Done';
            const item = document.createElement('div');
            item.className = `linked-task-item d-flex align-items-start gap-2 ${isDone ? 'task-done' : ''}`;
            
            // Thêm onclick để mở modal chi tiết
            item.innerHTML = `
                <div class="form-check pt-1">
                    <input class="form-check-input cursor-pointer toggle-linked-task" 
                           type="checkbox" 
                           data-task-id="${task.id}" 
                           ${isDone ? 'checked' : ''}
                           title="Đánh dấu hoàn thành/chưa hoàn thành">
                </div>
                <div class="flex-grow-1" style="line-height: 1.3;">
                    <div class="task-text fw-bold text-dark small ${isDone ? 'text-decoration-line-through' : ''}"
                         title="Bấm để xem/sửa chi tiết task này"
                         onclick="window.openTaskDetail('${task.id}')">
                        ${task.what}
                    </div>
                    <div class="d-flex align-items-center mt-1">
                         <span class="badge bg-light text-secondary border px-2" style="font-weight: normal; font-size: 0.7rem;">
                            <i class="fa-solid fa-user me-1"></i>${task.who || 'N/A'}
                         </span>
                    </div>
                </div>
            `;
            container.appendChild(item);
        });

        bindTaskToggleEvents();
    }

    function bindTaskToggleEvents() {
        document.querySelectorAll('.toggle-linked-task').forEach(chk => {
            chk.addEventListener('change', function() {
                const taskId = this.dataset.taskId;
                const newStatus = this.checked ? 'Done' : 'Pending';
                
                fetch('/update-task-status', { 
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ taskId: taskId, newStatus: newStatus })
                })
                .then(r => r.json())
                .then(data => {
                    if(data.success) {
                        refreshCurrentNoteData(); 
                    } else {
                        alert('Lỗi: ' + data.message);
                        this.checked = !this.checked; 
                    }
                })
                .catch(e => { console.error(e); this.checked = !this.checked; });
            });
        });
    }

    async function refreshCurrentNoteData() {
        const noteId = document.getElementById('editNoteId').value;
        if(!noteId) return;
        try {
            const res = await fetch(NOTE_API_URL_BASE.replace('/0', '/' + noteId));
            const data = await res.json();
            if(data.success) {
                renderLinkedTasksInModal(data.note.linked_tasks);
                updateCardContentUI(data.note); 
            }
        } catch(e) { console.error(e); }
    }
    
    window.refreshCurrentNoteData = refreshCurrentNoteData;

    // [FIXED] Hàm mở modal chi tiết task khi click vào tên task
    // Đã sửa lại đường dẫn API để khớp với routes.py hiện có
    window.openTaskDetail = async function(taskId) {
        try {
            // 1. GỌI API LẤY CHI TIẾT (Sửa thành /api/task/...)
            const response = await fetch(`/api/task/${taskId}`);
            
            if (response.status === 404) {
                alert(`Lỗi 404: Không tìm thấy API /api/task/${taskId}`);
                return;
            }
            
            const data = await response.json();
            const task = data.task || data; 

            if (!task || !task.id) {
                alert('Dữ liệu task trả về không hợp lệ.');
                return;
            }

            // 2. Điền dữ liệu vào Form
            const modalEl = document.getElementById('taskModal');
            if (!modalEl) return alert('Không tìm thấy Modal Task (ID: taskModal).');
            
            const form = document.getElementById('taskForm');
            if(form) form.reset();

            // Hàm helper để điền value an toàn
            const setVal = (id, val) => {
                const el = document.getElementById(id);
                if (el) el.value = (val !== undefined && val !== null) ? val : "";
            };

            setVal('taskId', task.id);
            setVal('taskWhat', task.what);
            setVal('taskStatus', task.status);
            setVal('taskWho', task.who_id);
            setVal('taskPriority', task.priority || "Medium");
            // Backend trả về task_date hoặc date tùy to_dict, check cả 2
            setVal('taskDate', task.task_date || task.date); 
            setVal('taskHour', task.hour);
            setVal('taskNote', task.note);
            setVal('taskProject', task.project_id);
            
            // Xử lý nút Xóa
            const deleteBtn = document.getElementById('deleteTaskBtn');
            if(deleteBtn) {
                deleteBtn.style.display = 'block';
                // Clone để xóa event listener cũ
                const newDeleteBtn = deleteBtn.cloneNode(true);
                deleteBtn.parentNode.replaceChild(newDeleteBtn, deleteBtn);
                
                newDeleteBtn.onclick = function() {
                    if(confirm("Bạn chắc chắn muốn xóa task này?")) {
                        // Gọi route /delete-task/<id> (POST) có sẵn trong routes.py
                        fetch(`/delete-task/${task.id}`, { method: 'POST' })
                        .then(r => r.json())
                        .then(d => {
                            if(d.success) {
                                bootstrap.Modal.getInstance(modalEl).hide();
                                refreshCurrentNoteData();
                            } else alert(d.message);
                        })
                        .catch(err => alert("Lỗi xóa task: " + err));
                    }
                };
            }

            // 3. Mở Modal
            const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
            modal.show();

        } catch (e) {
            console.error("OpenTaskDetail Error:", e);
            alert(`Lỗi tải task: ${e.message}`);
        }
    };
    
    // [FIXED] Xử lý Submit Form (Lưu Task)
    // Sử dụng route /save-task có sẵn trong routes.py
    const taskForm = document.getElementById('taskForm');
    if (taskForm) {
        const newForm = taskForm.cloneNode(true);
        taskForm.parentNode.replaceChild(newForm, taskForm);
        
        newForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            const fd = new FormData(newForm);
            
            try {
                // Gọi route /save-task (POST FormData)
                const res = await fetch('/save-task', { 
                    method: 'POST', 
                    body: fd 
                });
                
                const respData = await res.json();
                if (respData.success) {
                    bootstrap.Modal.getInstance(document.getElementById('taskModal')).hide();
                    await refreshCurrentNoteData();
                } else {
                    alert('Lỗi khi lưu: ' + respData.message);
                }
            } catch(err) {
                console.error(err);
                alert('Lỗi kết nối server khi lưu task.');
            }
        });
    }


    // --- 3. SỰ KIỆN CLICK TRÊN BOARD (GIỮ NGUYÊN) ---
    board.addEventListener('click', function(e) {
        const card = e.target.closest('.trello-card');
        
        // A. Click Label
        const labelDot = e.target.closest('.label-dot');
        if (labelDot && card) {
            e.stopPropagation();
            const noteId = card.dataset.noteId;
            const label = labelDot.dataset.label;
            const isOff = labelDot.classList.contains('active');
            const newLabel = isOff ? null : label;

            fetch(NOTE_API_URL_BASE.replace('/0', '/' + noteId), {
                method: 'PUT', headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ label: newLabel })
            })
            .then(r=>r.json()).then(d => { if(d.success) updateCardLabelUI(card, newLabel); });
            return;
        }

        // B. Click vào Card -> MỞ MODAL NOTE
        if (card && e.target.closest('.card-main-content')) {
            const noteId = card.dataset.noteId;
            const url = NOTE_API_URL_BASE.replace('/0', '/' + noteId);

            fetch(url)
                .then(res => res.json())
                .then(data => {
                    if (!data.success) return alert(data.message);
                    const note = data.note;

                    document.getElementById('editNoteId').value = note.id;
                    document.getElementById('editNoteTitle').value = note.title;
                    const colSelect = document.getElementById('editNoteColumnSelect');
                    if(colSelect) colSelect.value = note.column_id;

                    const attList = document.getElementById('edit-note-attachment-list');
                    attList.innerHTML = '';
                    if (note.attachments && note.attachments.length) {
                        note.attachments.forEach(att => {
                            attList.innerHTML += `
                            <div class="d-flex justify-content-between align-items-center mb-1 p-2 border rounded bg-white" id="file-${att.id}">
                                <a href="${att.url}" target="_blank" class="text-truncate text-decoration-none text-dark small">
                                    <i class="fa-solid fa-paperclip me-1"></i>${att.original_filename}
                                </a>
                                <button type="button" class="btn btn-sm text-danger delete-attachment-btn p-0 ms-2" data-file-id="${att.id}">
                                    <i class="fa-solid fa-times"></i>
                                </button>
                            </div>`;
                        });
                    }

                    if (note.linked_tasks) {
                        renderLinkedTasksInModal(note.linked_tasks);
                    } else {
                        renderLinkedTasksInModal([]);
                    }

                    currentEditorContent = note.content || "";
                    editNoteModal.show();
                })
                .catch(err => console.error(err));
        }

        handleBoardActions(e);
    });

    // --- 4. CÁC HÀM TOÀN CỤC ---
    window.saveNoteContent = async function() {
        if (!toastEditor) return; 

        const id = document.getElementById('editNoteId').value;
        const title = document.getElementById('editNoteTitle').value;
        const columnId = document.getElementById('editNoteColumnSelect').value;
        const content = toastEditor.getMarkdown();
        const fileInput = document.getElementById('edit-note-attachments');
        
        try {
            if (fileInput.files.length > 0) {
                const fd = new FormData();
                fd.append('title', title);
                fd.append('content', content);
                fd.append('column_id', columnId);
                for(let f of fileInput.files) fd.append('attachments[]', f);
                
                const res = await fetch(NOTE_API_URL_BASE.replace('/0', '/' + id), { method: 'PUT', body: fd });
                const d = await res.json();
                if(d.success) window.location.reload(); 
                else alert(d.message);
            } else {
                const res = await fetch(NOTE_API_URL_BASE.replace('/0', '/' + id), {
                    method: 'PUT', headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ title, content, column_id: columnId })
                });
                const d = await res.json();
                if(d.success) {
                    updateCardContentUI(d.note);
                    alert("Đã lưu ghi chú!");
                } else alert(d.message);
            }
        } catch(e) { console.error(e); alert("Lỗi lưu dữ liệu"); }
    };

    // --- 5. UI UPDATERS (GIỮ NGUYÊN) ---
    function updateCardLabelUI(card, label) {
        if (!card) return;
        card.classList.remove('card-label-red', 'card-label-green', 'card-label-blue');
        if (label) card.classList.add(`card-label-${label.toLowerCase()}`);
        card.querySelectorAll('.label-dot').forEach(dot => {
            dot.classList.toggle('active', dot.dataset.label === label);
        });
    }

    function renderCardHtml(note) {
        const creatorUsername = note.creator && note.creator.username ? note.creator.username : 'N/A';
        const labelClass = note.label ? `card-label-${note.label.toLowerCase()}` : '';
        const activeRed = note.label === 'Red' ? 'active' : '';
        const activeGreen = note.label === 'Green' ? 'active' : '';
        const activeBlue = note.label === 'Blue' ? 'active' : '';

        let progressHtml = '';
        let allDoneClass = '';
        let checkIcon = '';

        if (note.task_progress && note.task_progress.has_tasks) {
            const p = note.task_progress;
            let barColor = 'bg-primary';
            
            if (p.percent === 100) {
                barColor = 'bg-success';
                allDoneClass = 'card-all-done';
                checkIcon = `<span class="badge bg-success bg-opacity-75 rounded-pill" style="font-size: 0.6rem;"><i class="fa-solid fa-check"></i></span>`;
            } else if (p.percent < 50) {
                barColor = 'bg-warning';
            }

            progressHtml = `
                <div class="mt-2">
                    <div class="d-flex justify-content-between small text-muted mb-1" style="font-size: 0.7rem;">
                        <span class="fw-bold ${p.percent === 100 ? 'text-success' : ''}">
                            <i class="fa-solid fa-list-check me-1"></i>${p.percent === 100 ? "Hoàn tất" : "Tiến độ"}
                        </span>
                        <span>${p.done}/${p.total}</span>
                    </div>
                    <div class="progress" style="height: 6px; border-radius: 3px; background-color: #e9ecef;">
                        <div class="progress-bar ${barColor}" role="progressbar" style="width: ${p.percent}%"></div>
                    </div>
                </div>
            `;
        }

        return `
            <div class="trello-card ${labelClass} ${allDoneClass}" data-note-id="${note.id}">
                <div class="card-main-content">
                    <div class="d-flex justify-content-between align-items-start">
                        <h6 class="card-title">${note.title}</h6>
                        ${checkIcon}
                    </div>
                    ${progressHtml}
                    <div class="card-footer-info">
                        <div class="d-flex align-items-center gap-1">
                            <div class="bg-secondary text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 20px; height: 20px; font-size: 0.6rem;">
                                ${creatorUsername.substring(0,2).toUpperCase()}
                            </div>
                        </div>
                        <div class="label-dots">
                            <span class="label-dot dot-red ${activeRed}" data-label="Red" title="Urgent"></span>
                            <span class="label-dot dot-green ${activeGreen}" data-label="Green" title="Normal"></span>
                            <span class="label-dot dot-blue ${activeBlue}" data-label="Blue" title="Low"></span>
                        </div>
                    </div>
                </div>
            </div>`;
    }

    function updateCardContentUI(note) {
        let oldCard = document.querySelector(`.trello-card[data-note-id="${note.id}"]`);
        const wrapper = document.createElement('div');
        wrapper.innerHTML = renderCardHtml(note).trim();
        const newCard = wrapper.firstChild;

        if (oldCard) {
            oldCard.replaceWith(newCard);
        } else {
            const col = document.querySelector(`.trello-list[data-column-id="${note.column_id}"] .trello-cards`);
            if (col) col.insertAdjacentElement('afterbegin', newCard);
        }
    }

    // --- 6. XỬ LÝ ACTION BOARD (ADD, DELETE, DRAG...) ---
    editNoteModalEl.addEventListener('click', function(e) {
        const btnFile = e.target.closest('.delete-attachment-btn');
        if (btnFile) {
            const fid = btnFile.dataset.fileId;
            if(confirm("Xóa file này?")) {
                fetch(DELETE_ATTACHMENT_URL.replace('/0', '/' + fid), {method:'POST'})
                .then(r=>r.json()).then(d=>{ if(d.success) document.getElementById('file-'+fid).remove(); });
            }
        }
        if (e.target.closest('#delete-note-btn-in-modal')) {
             const id = document.getElementById('editNoteId').value;
             if(confirm("Xóa note này vĩnh viễn?")) {
                 fetch(NOTE_API_URL_BASE.replace('/0', '/' + id), {method:'DELETE'})
                 .then(r=>r.json()).then(d=>{ if(d.success) { editNoteModal.hide(); document.querySelector(`.trello-card[data-note-id="${id}"]`).remove(); }});
             }
        }
    });

    function handleBoardActions(e) {
        const addCardLink = e.target.closest('.add-card-link');
        if (addCardLink) {
            e.preventDefault();
            const footer = addCardLink.closest('.list-footer');
            footer.querySelector('.add-card-form').style.display = 'block';
            footer.querySelector('.new-card-title').focus();
            addCardLink.style.display = 'none';
        }
        const cancelBtn = e.target.closest('.cancel-add-card-btn');
        if (cancelBtn) {
            const footer = cancelBtn.closest('.list-footer');
            footer.querySelector('.add-card-form').style.display = 'none';
            footer.querySelector('.add-card-link').style.display = 'block';
            footer.querySelector('.new-card-title').value = '';
        }
        const saveBtn = e.target.closest('.save-card-btn');
        if (saveBtn) {
            const footer = saveBtn.closest('.list-footer');
            const column = footer.closest('.trello-list');
            const textarea = footer.querySelector('.new-card-title');
            const title = textarea.value.trim();
            const columnId = column.dataset.columnId;
            if (!title) return textarea.focus();
            
            fetch(CREATE_NOTE_URL, {
                method: 'POST', headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ title: title, column_id: columnId })
            }).then(r=>r.json()).then(data => {
                if(data.success) {
                    const cardsContainer = column.querySelector('.trello-cards');
                    const wrapper = document.createElement('div');
                    wrapper.innerHTML = renderCardHtml(data.note).trim();
                    cardsContainer.insertAdjacentElement('afterbegin', wrapper.firstChild);

                    textarea.value = '';
                    footer.querySelector('.add-card-form').style.display = 'none';
                    footer.querySelector('.add-card-link').style.display = 'block';
                }
            });
        }
        const delColBtn = e.target.closest('.delete-column-btn');
        if (delColBtn) {
            e.preventDefault();
            if(confirm('Xóa cột này? Tất cả note bên trong sẽ bị xóa.')) {
                 const col = delColBtn.closest('.trello-list');
                 fetch(DELETE_COLUMN_URL.replace('/0', '/' + col.dataset.columnId), {method:'DELETE'})
                 .then(r=>r.json()).then(d=>{ if(d.success) col.remove(); });
            }
        }
    }

    const columns = document.querySelectorAll('.trello-cards');
    columns.forEach(col => {
        new Sortable(col, {
            group: 'shared', animation: 150,
            onEnd: function (evt) {
                const item = evt.item;
                const newColId = evt.to.closest('.trello-list').dataset.columnId;
                const noteId = item.dataset.noteId;
                fetch(NOTE_API_URL_BASE.replace('/0', '/' + noteId), {
                    method: 'PUT', headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ column_id: newColId })
                });
            }
        });
    });
    new Sortable(document.getElementById('notes-board'), {
         handle: '.trello-list-header', animation: 150,
         onEnd: function() {
             const order = [...document.querySelectorAll('.trello-list')].map(c => c.dataset.columnId);
             fetch(UPDATE_COLUMN_ORDER_URL, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({order})});
         }
    });

    board.addEventListener('dblclick', function(e) {
        const columnTitleEl = e.target.closest('.column-title');
        if (!columnTitleEl) return;
        const columnId = columnTitleEl.closest('.trello-list').dataset.columnId;
        const currentName = columnTitleEl.textContent.trim();
        const input = document.createElement('input');
        input.type = 'text'; input.value = currentName;
        input.className = 'form-control form-control-sm fw-bold';
        columnTitleEl.replaceWith(input);
        input.focus();
        
        const saveName = () => {
            const newName = input.value.trim();
            if (newName && newName !== currentName) {
                fetch(RENAME_COLUMN_URL.replace('/0', '/' + columnId), {
                    method: 'POST', headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ name: newName })
                }).then(r=>r.json()).then(d => { window.location.reload(); });
            } else input.replaceWith(columnTitleEl);
        };
        input.addEventListener('blur', saveName);
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') input.blur();
            if (e.key === 'Escape') { input.value = currentName; input.blur(); }
        });
    });

    const createColForm = document.getElementById('createColumnForm');
    if(createColForm) {
        createColForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('createColumnName').value;
            fetch(CREATE_COLUMN_URL, {
                method: 'POST', headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({name})
            }).then(r=>r.json()).then(d=>{ if(d.success) window.location.reload(); });
        });
    }
});