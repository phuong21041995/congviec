import os
import sys
from flask import Flask, jsonify
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_login import LoginManager
from jinja2 import ChoiceLoader, FileSystemLoader
from config import Config
from zoneinfo import ZoneInfo
from datetime import datetime

# Fallback hashing ngắn nếu cần (tránh crash khi password_hash còn 128)
from werkzeug.security import generate_password_hash

from sqlalchemy import select
from sqlalchemy.exc import DataError, StatementError

# --- THAY ĐỔI 1: IMPORT CÁC THÀNH PHẦN CẦN THIẾT ---
from app.custom_session import CustomSession
from sqlalchemy.orm import sessionmaker


migrate = Migrate()
# --- THAY ĐỔI 2: KHỞI TẠO DB VỚI SESSION TÙY CHỈNH ---
db = SQLAlchemy(session_options={"class_": CustomSession})
bcrypt = Bcrypt()
login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.login_message = 'Vui lòng đăng nhập để tiếp tục.'
login_manager.login_message_category = 'warning'


# --- Jinja2 filter: UTC -> giờ VN (hoặc tz tuỳ chọn) ---
def to_local_time(value, tz_name='Asia/Ho_Chi_Minh', fmt='%Y-%m-%d %H:%M'):
    if not value:
        return ''
    try:
        if getattr(value, 'tzinfo', None) is None:
            value = value.replace(tzinfo=ZoneInfo('UTC'))
        return value.astimezone(ZoneInfo(tz_name)).strftime(fmt)
    except Exception:
        return str(value)


def exe_dir():
    return os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) else os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))


def candidate_dirs(name):
    root = exe_dir()
    pkg_dir = os.path.dirname(__file__)
    cands = []
    if hasattr(sys, '_MEIPASS'):
        cands.append(os.path.join(sys._MEIPASS, 'app', name))  # type: ignore[attr-defined]
    cands.append(os.path.join(root, '_internal', 'app', name))
    cands.append(os.path.join(root, 'app', name))
    cands.append(os.path.join(pkg_dir, name))
    cands.append(os.path.join(root, name))
    return cands


def pick_first_existing(paths):
    for p in paths:
        if os.path.isdir(p):
            return p
    return paths[0]


def create_app(config_class=Config):
    cand_templates = candidate_dirs('templates')
    cand_static    = candidate_dirs('static')
    templates_dir  = pick_first_existing(cand_templates)
    static_dir     = pick_first_existing(cand_static)

    app = Flask(__name__, template_folder=templates_dir, static_folder=static_dir)
    app.config.from_object(config_class)

    # Prepare uploads folder
    try:
        upload_folder = app.config['UPLOAD_FOLDER']
        if not os.path.exists(upload_folder):
            os.makedirs(upload_folder)
            print(f"Đã tạo thư mục uploads tại: {upload_folder}")
    except Exception as e:
        print(f"Lỗi khi tạo thư mục uploads: {e}")

    if not app.config.get('SECRET_KEY'):
        app.config['SECRET_KEY'] = 'change-me-please'

    # Normalize sqlite paths to absolute (portable build) for both URI and BINDS
    uri = app.config.get('SQLALCHEMY_DATABASE_URI', '')
    if uri.startswith('sqlite:///'):
        rel = uri.replace('sqlite:///', '')
        if not os.path.isabs(rel):
            abs_db = os.path.join(exe_dir(), rel)
            os.makedirs(os.path.dirname(abs_db), exist_ok=True)
            app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{abs_db}'
    
    binds = app.config.get('SQLALCHEMY_BINDS', {})
    for key, bind_uri in binds.items():
        if bind_uri.startswith('sqlite:///'):
            rel = bind_uri.replace('sqlite:///', '')
            if not os.path.isabs(rel):
                abs_db = os.path.join(exe_dir(), rel)
                os.makedirs(os.path.dirname(abs_db), exist_ok=True)
                app.config['SQLALCHEMY_BINDS'][key] = f'sqlite:///{abs_db}'


    db.init_app(app)

    # --- THAY ĐỔI 3: XÓA BỎ VIỆC GHI ĐÈ db.session CŨ ---
    # Dòng code cũ "from app.db_session import Session" và "db.session = Session"
    # đã được xóa bỏ.

    migrate.init_app(app, db)
    bcrypt.init_app(app)
    login_manager.init_app(app)

    app.jinja_env.filters['to_local_time'] = to_local_time
    app.jinja_loader = ChoiceLoader([FileSystemLoader(p) for p in cand_templates])

    # Import models so Alembic thấy metadata
    from . import models  # noqa: F401

    # --- SỬA LỖI ---
    # Đoạn code này giờ chỉ còn 1 dòng duy nhất để tạo bảng cho tất cả DBs
    with app.app_context():
        # Lệnh này sẽ tự động tạo các bảng cần thiết trong TẤT CẢ
        # các database đã được cấu hình (cả chung và cá nhân)
        db.create_all(bind_key='__all__')
    # --- KẾT THÚC SỬA LỖI ---


    # --- ĐĂNG KÝ CÁC BLUEPRINT ---
    from .auth import bp as auth_bp
    app.register_blueprint(auth_bp)

    from .routes import bp as main_bp
    app.register_blueprint(main_bp)

    # API uploads
    from .uploads_api import bp as uploads_api_bp
    app.register_blueprint(uploads_api_bp)

    # --- Route chẩn đoán template ---
    @app.route('/__diag__/templates')
    def _diag_templates():
        targets = ['auth/login.html', 'login.html', 'index.html', 'base.html']
        search = cand_templates
        found = {t: [os.path.join(p, t) for p in search if os.path.isfile(os.path.join(p, t))] for t in targets}
        return jsonify({
            "template_folder": app.template_folder,
            "static_folder": app.static_folder,
            "search_paths": search,
            "exists": {p: os.path.isdir(p) for p in search},
            "found": found,
        })

    app.logger.info('TEMPLATE picked: %s', app.template_folder)
    app.logger.info('STATIC   picked: %s', app.static_folder)
    app.logger.info('SEARCH PATHS   : %s', cand_templates)

    from .models import User

    @login_manager.user_loader
    def load_user(user_id):
        """
        Hàm này phải LUÔN LUÔN dùng database chung để tìm user,
        bất kể người dùng đang chọn chế độ nào.
        """
        try:
            # Lấy engine của database chung (mặc định)
            engine = db.get_engine()
            
            # Tạo một "nhà máy" session tạm thời, buộc nó kết nối với engine chung
            TempSession = sessionmaker(bind=engine)
            
            # Tạo một session từ nhà máy và sử dụng nó
            with TempSession() as temp_session:
                # Dùng session tạm thời này để lấy user
                user = temp_session.get(User, int(user_id))
                return user
        except Exception as e:
            # In lỗi ra console để dễ debug nếu có vấn đề
            print(f"Error in load_user: {e}")
            return None

 

    # --- Jinja filters tiện ích ---
    def format_date_short(date_string):
        """Format 'YYYY-MM-DD' -> 'DD/MM'."""
        if isinstance(date_string, str):
            try:
                dt_obj = datetime.strptime(date_string, '%Y-%m-%d')
                return dt_obj.strftime('%d/%m')
            except ValueError:
                return date_string
        return date_string

    def to_date_obj(date_string):
        """Convert 'YYYY-MM-DD' string to a date object."""
        if isinstance(date_string, str):
            try:
                return datetime.strptime(date_string, '%Y-%m-%d').date()
            except (ValueError, TypeError):
                return None
        return None

    app.jinja_env.filters['format_date_short'] = format_date_short
    app.jinja_env.filters['to_date'] = to_date_obj

    return app




