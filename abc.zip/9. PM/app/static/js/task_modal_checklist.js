/**
 * Tối ưu UI/UX Checklist: Kéo thả mượt mà với Drag Handle, CSS hiện đại.
 */
document.addEventListener('DOMContentLoaded', function () {
    const subtaskListContainer = document.getElementById('subtaskListContainer');
    const newSubtaskInput = document.getElementById('newSubtaskInput');
    const addSubtaskBtn = document.getElementById('addSubtaskBtn');
    const taskForm = document.getElementById('taskForm');
    const progressContainer = document.getElementById('checklistProgressContainer');
    const progressText = document.getElementById('checklistProgressText');
    const progressBar = document.getElementById('checklistProgressBar');

    let currentOpeningTaskId = null;

    // --- BƯỚC 1: NHÚNG CSS NÂNG CẤP GIAO DIỆN ---
    const style = document.createElement('style');
    style.innerHTML = `
        /* Container bọc ngoài cho gọn gàng */
        #subtaskListContainer { 
            counter-reset: modal-idx; 
            border: 1px solid #e5e7eb; 
            border-radius: 8px; 
            background: #ffffff;
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            overflow: hidden;
            margin-bottom: 15px;
        }
        
        /* Từng dòng task */
        .subtask-item { 
            display: flex; 
            align-items: center; 
            padding: 0px 0px; 
            border-bottom: 1px solid #f3f4f6; 
            background: #ffffff;
            transition: all 0.2s ease;
        }
        .subtask-item:last-child { border-bottom: none; }
        .subtask-item:hover { background: #f9fafb; }
        
        /* Drag handle (Tay cầm kéo thả) */
        .drag-handle {
            cursor: grab;
            color: #d1d5db;
            margin-right: 12px;
            font-size: 14px;
            padding: 4px;
            transition: color 0.2s;
        }
        .subtask-item:hover .drag-handle { color: #9ca3af; }
        .drag-handle:active { cursor: grabbing; }

        /* Đánh số tự động */
        .subtask-item::before {
            counter-increment: modal-idx;
            content: counter(modal-idx) ".";
            margin-right: 12px; 
            font-weight: 600; 
            color: #3b82f6; 
            min-width: 20px;
			font-size: 13px;
        }

        /* Checkbox to và rõ ràng hơn */
        .custom-checkbox {
            width: 18px;
            height: 18px;
            cursor: pointer;
            margin-right: 12px;
            accent-color: #3b82f6;
        }

        /* Input text */
        .subtask-input {
            border: none;
            background: transparent;
            flex-grow: 1;
            font-size: 13px;
            color: #374151;
            outline: none;
            transition: color 0.2s;
        }
        .subtask-input:focus { color: #111827; }

        /* Nút xóa ẩn đi, chỉ hiện khi hover để UI bớt rác */
        .remove-subtask-btn { 
            color: #ef4444; 
            opacity: 0; 
            transition: opacity 0.2s, transform 0.2s; 
            padding: 4px 8px;
        }
        .subtask-item:hover .remove-subtask-btn { opacity: 1; transform: scale(1.1); }
        .remove-subtask-btn:hover { color: #dc2626; }

        /* Hiệu ứng khi kéo thả */
        .sortable-ghost { 
            opacity: 0.5; 
            background: #eff6ff !important; 
            border: 1px dashed #3b82f6; 
        }
        
        /* Hiệu ứng khi đã check Done */
        .subtask-item.done .subtask-input { 
            text-decoration: line-through; 
            color: #9ca3af; 
        }
        .subtask-item.done::before { opacity: 0.5; }
    `;
    document.head.appendChild(style);

    if (!subtaskListContainer || !newSubtaskInput || !addSubtaskBtn || !taskForm) return;

    /**
     * Cập nhật thanh tiến độ
     */
    const updateChecklistProgress = () => {
        const allItems = subtaskListContainer.querySelectorAll('.subtask-item');
        const completedItems = subtaskListContainer.querySelectorAll('.subtask-item input[type="checkbox"]:checked');
        const total = allItems.length;
        const completed = completedItems.length;

        if (total === 0) {
            subtaskListContainer.style.border = 'none'; // Ẩn viền nếu không có item
            if(progressContainer) progressContainer.style.display = 'none';
            return;
        }

        subtaskListContainer.style.border = '1px solid #e5e7eb'; // Hiện viền lại
        if(progressContainer) progressContainer.style.display = 'block';
        const percentage = Math.round((completed / total) * 100);
        if(progressText) progressText.textContent = `${completed}/${total}`;
        if(progressBar) {
            progressBar.style.width = `${percentage}%`;
            progressBar.textContent = `${percentage}%`;
            // Đổi màu thanh progress nếu hoàn thành 100%
            progressBar.style.backgroundColor = percentage === 100 ? '#22c55e' : '#3b82f6';
        }
    };

    /**
     * Vẽ một dòng checklist
     */
    const renderSubtaskItem = (subtask = {}) => {
        const id = subtask.id || `new_${Date.now()}`;
        const content = subtask.content || '';
        const is_done = subtask.is_done || false;

        const itemWrapper = document.createElement('div');
        itemWrapper.className = 'subtask-item'; 
        if (is_done) itemWrapper.classList.add('done');
        itemWrapper.dataset.id = id;
        itemWrapper.dataset.isNew = String(subtask.id ? false : true);

        // Thêm icon grip-vertical làm drag handle
        itemWrapper.innerHTML = `
            <i class="fa-solid fa-grip-vertical drag-handle" title="Kéo để di chuyển"></i>
            <input class="custom-checkbox" type="checkbox" ${is_done ? 'checked' : ''}>
            <input type="text" class="subtask-input" value="${content}" placeholder="Nhập tên việc cần làm...">
            <button type="button" class="btn btn-sm btn-link remove-subtask-btn" title="Xóa">
                <i class="fa-solid fa-times"></i>
            </button>
        `;
        
        itemWrapper.querySelector('input[type="checkbox"]').addEventListener('change', function() {
            itemWrapper.classList.toggle('done', this.checked);
            updateChecklistProgress();
        });

        subtaskListContainer.appendChild(itemWrapper);
    };

    /**
     * API hiển thị Checklist (Đã tích hợp sắp xếp từ DB)
     */
    window.renderChecklist = (subtasks = [], taskId = null) => {
        subtaskListContainer.innerHTML = '';
        currentOpeningTaskId = taskId;
        if (subtasks && subtasks.length > 0) {
            subtasks.forEach(renderSubtaskItem);
        }
        updateChecklistProgress();
    };

    /**
     * BƯỚC 2: KÍCH HOẠT KÉO THẢ (SORTABLE JS)
     */
    if (typeof Sortable !== 'undefined') {
        new Sortable(subtaskListContainer, {
            animation: 150,
            ghostClass: 'sortable-ghost',
            handle: '.drag-handle', // CHỈ CHO PHÉP KÉO KHI NẮM VÀO ICON NÀY
            onEnd: function() {
                const items = subtaskListContainer.querySelectorAll('.subtask-item');
                const newOrderIds = Array.from(items).map(el => el.dataset.id);
                
                // Gửi thứ tự mới lên Server để lưu vào cột 'position'
                fetch('/api/subtask/reorder', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ ids: newOrderIds })
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success && typeof showSaveIndicator === 'function') {
                        showSaveIndicator("Thứ tự đã được lưu lại");
                    }
                });
            }
        });
    }

    // --- CÁC HÀM XỬ LÝ SỰ KIỆN KHÁC ---
    addSubtaskBtn.addEventListener('click', () => {
        const content = newSubtaskInput.value.trim();
        if (content) {
            renderSubtaskItem({ content: content, is_done: false });
            newSubtaskInput.value = '';
            updateChecklistProgress();
        }
    });

    newSubtaskInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') { e.preventDefault(); addSubtaskBtn.click(); }});

    subtaskListContainer.addEventListener('click', (e) => {
        const removeBtn = e.target.closest('.remove-subtask-btn');
        if (removeBtn) {
            removeBtn.closest('.subtask-item').remove();
            updateChecklistProgress();
        }
    });

    window.prepareSubtasksForSubmission = () => {
        const subtaskItems = subtaskListContainer.querySelectorAll('.subtask-item');
        const subtasksData = [];
        subtaskItems.forEach(itemEl => {
            const id = itemEl.dataset.id;
            const contentInput = itemEl.querySelector('.subtask-input');
            const isDoneCheckbox = itemEl.querySelector('input[type="checkbox"]');
            if (contentInput && contentInput.value.trim()) {
                subtasksData.push({
                    id: isNaN(parseInt(id)) ? null : parseInt(id),
                    content: contentInput.value.trim(),
                    is_done: isDoneCheckbox.checked
                });
            }
        });
        const subtasksInput = document.getElementById('subTasksInput'); 
        if (subtasksInput) subtasksInput.value = JSON.stringify(subtasksData);
    };
});