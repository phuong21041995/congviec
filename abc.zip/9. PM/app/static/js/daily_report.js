/**
 * Core Logic for Daily Engineering Report
 */

// --- 1. X3 LOGIC & KAIZEN ---
function quickSaveX3() {
    const payload = {
        date: window.CURRENT_DATE_STR,
        daily_objective: document.getElementById('x3-objective').value,
        pain_point: document.getElementById('x3-pain-point').value,
        root_cause: document.getElementById('x3-root-cause').value,
        kaizen_result: document.getElementById('x3-kaizen-result').value,
        kaizen_cause: document.getElementById('x3-kaizen-cause').value,
        kaizen_action: document.getElementById('x3-kaizen-action').value,
        kaizen_lesson: document.getElementById('x3-kaizen-lesson').value
    };
    showSaveIndicator("Lưu Tiêu điểm...");
    fetch('/api/x3/save', { 
        method: 'POST', 
        headers: { 'Content-Type': 'application/json' }, 
        body: JSON.stringify(payload) 
    })
    .then(res => res.json())
    .then(data => {
        if(data.success) { 
            showSaveIndicator("Đã lưu X3"); 
            setTimeout(() => document.getElementById('save-indicator').style.display='none', 1000); 
        }
    }).catch(err => console.error(err));
}

// Gọi Modal AI Khuyến nghị
function generateKaizenSummary() {
    const modal = new bootstrap.Modal(document.getElementById('aiKaizenModal'));
    modal.show();
    const contentBox = document.getElementById('ai-kaizen-content');
    
    // UI lúc đang load
    contentBox.innerHTML = '<div class="text-center py-4"><div class="spinner-border text-primary spinner-border-sm" role="status"></div><p class="mt-2 text-muted small fw-bold">Đang phân tích dữ liệu ngày...</p></div>';

    fetch('/api/x3/summarize-kaizen?date=' + window.CURRENT_DATE_STR)
    .then(res => res.json())
    .then(data => {
        if(data.success) {
            contentBox.innerHTML = `
                <div class="alert alert-success border-0 shadow-sm mb-3">
                    <strong class="d-block mb-1" style="font-size:12px;"><i class="fa-solid fa-trophy text-warning me-1"></i>KẾT QUẢ ĐẠT ĐƯỢC:</strong>
                    <span style="font-size:13px; color:#1e293b;">${data.summary.result}</span>
                </div>
                <div class="alert alert-warning border-0 shadow-sm mb-3">
                    <strong class="d-block mb-1" style="font-size:12px;"><i class="fa-solid fa-book-open text-primary me-1"></i>BÀI HỌC RÚT RA:</strong>
                    <span style="font-size:13px; color:#1e293b;">${data.summary.lesson}</span>
                </div>
                <div class="alert alert-primary border-0 shadow-sm mb-0">
                    <strong class="d-block mb-1" style="font-size:12px;"><i class="fa-solid fa-person-running text-danger me-1"></i>HÀNH ĐỘNG KHẮC PHỤC:</strong>
                    <span style="font-size:13px; color:#1e293b;">${data.summary.action}</span>
                </div>
                <div class="text-center mt-3"><span class="badge bg-light text-secondary border px-3 py-2"><i class="fa-regular fa-lightbulb me-1 text-warning"></i> Tham khảo nội dung này để tự viết Kaizen</span></div>
            `;
        } else {
            contentBox.innerHTML = `<div class="alert alert-danger">Lỗi: ${data.message}</div>`;
        }
    })
    .catch(() => {
        contentBox.innerHTML = `<div class="alert alert-danger">Mất kết nối đến Trợ lý AI.</div>`;
    });
}

// --- 2. QUICK ADD & INLINE EDIT ---
function startEdit(spanEl) {
    if(spanEl.querySelector('input')) return;
    const currentText = spanEl.innerText;
    const wrap = spanEl.closest('.editable-wrap');
    const id = wrap.dataset.id;
    const type = wrap.dataset.type;

    const input = document.createElement('input');
    input.type = 'text'; input.className = 'editable-input'; input.value = currentText;

    const save = async () => {
        const newText = input.value.trim();
        if (!newText || newText === currentText) { wrap.innerHTML = ''; wrap.appendChild(spanEl); return; }
        input.disabled = true;
        try {
            let res, data;
            if (type === 'habit') {
                res = await fetch(`/api/habits/update`, { method: 'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({habit_id: id, name: newText}) });
            }
            data = await res.json();
            if (data.success) spanEl.innerText = newText;
        } catch(e) { console.error(e); }
        wrap.innerHTML = ''; wrap.appendChild(spanEl);
    };

    input.onblur = save;
    input.onkeydown = (e) => { if (e.key === 'Enter') save(); if (e.key === 'Escape') { wrap.innerHTML = ''; wrap.appendChild(spanEl); } };
    wrap.innerHTML = ''; wrap.appendChild(input); input.focus(); input.setSelectionRange(input.value.length, input.value.length); 
}

async function handleQuickAdd(event, type, inputEl) {
    if (event.key === 'Enter') {
        const content = inputEl.value.trim(); if (!content) return;
        inputEl.disabled = true; 
        
        let hour = null;
        let finalContent = content; // Nội dung cuối cùng sẽ gửi lên
        
        // Lấy Project ID & Project Name (để ghép vào tên task)
        const container = inputEl.closest('.input-group');
        const projSelect = container.querySelector('select');
        const projId = projSelect ? projSelect.value : '';
        
        if (projId) {
            const projOption = projSelect.options[projSelect.selectedIndex];
            if (projOption.text !== 'Cá nhân') {
                const projName = projOption.text.replace('..', '').trim(); // Cắt dấu .. nếu có
                finalContent = `[${projName}] ${content}`;
            }
        }

        // Lấy Giờ (từ time picker)
        if (type === 'fixed') {
            const timePicker = container.querySelector('#quick-add-time');
            if(timePicker && timePicker.value) {
                hour = timePicker.value;
            } else {
                hour = "08:00"; // Default fallback
            }
        }

        const formData = new FormData();
        formData.append('taskWhat', finalContent); // Gửi tên đã có [Project]
        formData.append('taskDate', window.CURRENT_DATE_STR); 
        formData.append('taskStatus', 'Pending'); 
        formData.append('taskWho', window.CURRENT_USER_ID);
        if (hour !== null) formData.append('taskHour', hour);
        if (projId) formData.append('taskProject', projId);

        try {
            const res = await fetch(window.SAVE_TASK_URL, { method: 'POST', body: formData });
            if ((await res.json()).success) window.location.reload(); 
            else inputEl.disabled = false;
        } catch (e) { inputEl.disabled = false; }
    }
}


// --- 3. QUICK TOGGLE STATUS (Không mở Modal) ---
async function toggleTaskQuick(iconEl, taskId) {
    const isDone = iconEl.classList.contains('done');
    const newStatus = isDone ? 'Pending' : 'Done';
    
    // Cập nhật UI ngay lập tức (Optimistic UI)
    iconEl.classList.toggle('done');
    iconEl.classList.toggle('pending');
    iconEl.classList.toggle('fa-square-check');
    iconEl.classList.toggle('fa-square');
    
    const rowEl = iconEl.closest('.list-row');
    const textSpan = rowEl.querySelector('.task-text');
    if(textSpan) {
        if(newStatus === 'Done') {
            textSpan.classList.add('task-done-text');
            textSpan.classList.remove('text-dark');
        } else {
            textSpan.classList.remove('task-done-text');
            textSpan.classList.add('text-dark');
        }
    }

    showSaveIndicator("Updating status...");
// TÌM HÀM toggleTaskQuick VÀ THAY THẾ PHẦN TRY CATCH NHƯ SAU:
    try {
        const res = await fetch('/update-task-status', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ taskId: taskId, newStatus: newStatus })
        });
        const data = await res.json();
        if(data.success) {
            document.getElementById('save-indicator').style.display='none';
            // 1. Cập nhật bảng chi tiết
            updateTableStatusUI(taskId, newStatus);
            
            // 2. CẬP NHẬT THANH % GLOBAL NGAY LẬP TỨC 
            if (data.global_progress !== undefined) {
                const gt = document.getElementById('global-progress-text');
                const gb = document.getElementById('global-progress-bar');
                if (gt) gt.innerText = data.global_progress; 
                if (gb) gb.style.width = data.global_progress + '%';
            }
        } else {
            alert("Lỗi: " + data.message);
            window.location.reload(); 
        }
    } catch(err) {
        console.error(err);
    }
}

function updateTableStatusUI(taskId, newStatus) {
    const badge = document.getElementById(`task-status-badge-${taskId}`);
    if(badge) {
        badge.innerText = newStatus;
        badge.className = 'status-pill';
        badge.classList.add(newStatus === 'Done' ? 'status-done' : 'status-pending');
        
        const progText = document.getElementById(`task-prog-text-${taskId}`);
        const progBar = document.getElementById(`task-prog-bar-${taskId}`);
        if(progText && progBar) {
            const pct = newStatus === 'Done' ? 100 : 0;
            progText.innerText = pct + '%';
            progText.style.color = pct === 100 ? '#166534' : '#1e293b';
            progBar.style.width = pct + '%';
            progBar.style.background = pct === 100 ? 'var(--success)' : '#3b82f6';
        }
    }
}

// Habit Toggle
async function handleQuickAddHabit(event) {
    if (event.key === 'Enter') {
        const input = event.target; const name = input.value.trim(); if (!name) return;
        input.disabled = true;
        try {
            const res = await fetch('/api/habits/add', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({name: name}) });
            if((await res.json()).success) window.location.reload();
        } catch(e) { input.disabled = false; }
    }
}

async function toggleHabit(id, rowEl) {
    try {
        await fetch('/api/habits/toggle', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({habit_id: id}) });
        const textSpan = rowEl.querySelector('.editable-text'); const icon = rowEl.querySelector('.fa-circle, .fa-circle-check');
        if (textSpan.classList.contains('habit-done-text')) {
            textSpan.classList.remove('habit-done-text'); icon.className = 'fa-solid fa-circle custom-check';
        } else {
            textSpan.classList.add('habit-done-text'); icon.className = 'fa-solid fa-circle-check text-success';
        }
    } catch(e) {}
}


// --- 4. PROJECT & REPORT LOGIC ---
function toggleProject(id) {
    const card = document.getElementById(`project-card-${id}`);
    if (!card) return;
    card.classList.toggle('collapsed');
    updateStorage();
}

function toggleAllProjects(expand) {
    document.querySelectorAll('.report-card').forEach(card => { if (expand) card.classList.remove('collapsed'); else card.classList.add('collapsed'); });
    updateStorage();
}

function updateStorage() {
    const collapsedState = {};
    document.querySelectorAll('.report-card').forEach(card => { collapsedState[card.id.replace('project-card-', '')] = card.classList.contains('collapsed'); });
    localStorage.setItem('report_collapsed', JSON.stringify(collapsedState));
}

document.addEventListener('DOMContentLoaded', () => {
    const collapsedState = JSON.parse(localStorage.getItem('report_collapsed') || '{}');
    Object.keys(collapsedState).forEach(id => { const card = document.getElementById(`project-card-${id}`); if (card && collapsedState[id]) card.classList.add('collapsed'); });
    initResizers();
});

function initResizers() {
    const tables = document.querySelectorAll('.report-table');
    const savedWidths = JSON.parse(localStorage.getItem('report_column_widths') || '{}');
    tables.forEach((table) => {
        table.querySelectorAll('th').forEach((th) => {
            const colId = th.getAttribute('data-col');
            if (savedWidths[colId]) th.style.width = savedWidths[colId];
            const resizer = th.querySelector('.resizer');
            if (!resizer) return;
            resizer.addEventListener('mousedown', (e) => {
                e.preventDefault(); resizer.classList.add('active');
                const startX = e.pageX, startWidth = th.offsetWidth;
                const onMouseMove = (moveEv) => { th.style.width = Math.max(60, startWidth + (moveEv.pageX - startX)) + 'px'; };
                const onMouseUp = () => {
                    resizer.classList.remove('active'); document.removeEventListener('mousemove', onMouseMove); document.removeEventListener('mouseup', onMouseUp);
                    savedWidths[colId] = th.style.width; localStorage.setItem('report_column_widths', JSON.stringify(savedWidths));
                    document.querySelectorAll(`th[data-col="${colId}"]`).forEach(otherTh => { otherTh.style.width = th.style.width; });
                };
                document.addEventListener('mousemove', onMouseMove); document.addEventListener('mouseup', onMouseUp);
            });
        });
    });
}

function toggleSubTaskInline(sid, element) {
    showSaveIndicator("Saving...");
    fetch(`/api/subtask/${sid}/toggle`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ report_date: window.CURRENT_DATE_STR }) })
    .then(res => res.json()).then(data => {
        if (data.success) {
            document.getElementById('save-indicator').style.display = 'none';
            if (data.is_done) element.classList.add('done'); else element.classList.remove('done');
            const tr = element.closest('tr');
            if (tr) {
                if (data.task_status) {
                    const sp = tr.querySelector('.status-pill');
                    if (sp) { sp.innerText = data.task_status; sp.className = 'status-pill'; sp.classList.add(data.task_status === 'Done' ? 'status-done' : (data.task_status === 'Pending' ? 'status-pending' : 'status-active')); }
                }
                if (data.progress_pct !== undefined) {
                    const pbf = tr.querySelector('.progress-bar-fill');
                    const pt = tr.querySelector('td:last-child span.fw-800');
                    if (pt) { pt.innerText = data.progress_pct + '%'; pt.style.color = data.progress_pct === 100 ? '#166534' : '#1e293b'; }
                    if (pbf) { pbf.style.width = data.progress_pct + '%'; pbf.style.background = data.progress_pct === 100 ? 'var(--success)' : '#3b82f6'; }
                }
            }
            if (data.global_progress !== undefined) {
                const gt = document.getElementById('global-progress-text');
                const gb = document.getElementById('global-progress-bar');
                if (gt) gt.innerText = data.global_progress; 
                if (gb) gb.style.width = data.global_progress + '%';
            }
        } else { showSaveIndicator("Lỗi lưu dữ liệu!"); }
    }).catch(err => { console.error(err); });
}

function addNewTask(projectId, projectName, buildId) {
    if (typeof window.openCreateModal === 'function') {
        window.openCreateModal({ date: window.CURRENT_DATE_STR, project_id: projectId });
        setTimeout(() => {
            if (window.renderChecklist) window.renderChecklist([]);
            const tf = document.getElementById('taskWhat'); if (tf) { tf.value = `[${projectName.split('|')[0].trim()}] `; tf.focus(); }
            const sd = document.getElementById('taskStartDate'); if (sd && !sd.value) sd.value = window.TODAY_DATE_STR;
            const ps = document.getElementById('taskProject'), bs = document.getElementById('taskBuild');
            if (ps && projectId && projectId !== 'None') {
                ps.value = projectId; ps.dispatchEvent(new Event('change')); 
                if (buildId && buildId !== 'None' && buildId !== '') { setTimeout(() => { if (bs) { bs.value = buildId; bs.dispatchEvent(new Event('change')); } }, 600); }
            }
        }, 550); 
    }
}

function addNewGlobalTask() {
     if (typeof window.openCreateModal === 'function') {
         window.openCreateModal({ date: window.CURRENT_DATE_STR });
         setTimeout(() => { const sd = document.getElementById('taskStartDate'); if (sd && !sd.value) sd.value = window.TODAY_DATE_STR; }, 300);
     }
}

function openTaskModal(taskId) {
    fetch(`/api/task/${taskId}`).then(res => res.json()).then(data => {
        if(data.success) {
            if (window.openEditModal) window.openEditModal(data.task);
            const sd = document.getElementById('taskStartDate'); if (sd) sd.value = data.task.start_date || ""; 
        }
    });
}

function quickSaveReportLink(inputEl, taskId, projectId) {
    showSaveIndicator("Saving link...");
    fetch(`/api/task/${taskId}/update-link`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ report_link: inputEl.value.trim(), project_id: projectId, report_date: window.CURRENT_DATE_STR }) })
    .then(res => res.json()).then(data => {
        if (data.success) {
            document.getElementById('save-indicator').style.display = 'none';
            const group = inputEl.closest('.input-group'); let btn = group.querySelector('a.btn-light');
            if (inputEl.value.trim() !== '') {
                if (!btn) { btn = document.createElement('a'); btn.className = 'btn btn-light border-start text-primary px-1'; btn.target = '_blank'; btn.innerHTML = '<i class="fa-solid fa-link" style="font-size: 9px;"></i>'; group.appendChild(btn); }
                btn.href = inputEl.value.trim();
            } else { if (btn) btn.remove(); }
        } else { alert("Lỗi lưu link: " + data.message); }
    }).catch(err => { console.error(err); });
}

// Modal Reload Listener
document.addEventListener('submit', function(e) {
    if(e.target && e.target.id === 'taskForm') {
        const taskId = document.getElementById('taskId').value;
        const modalEl = document.getElementById('taskModal');
        const onHide = function() {
            modalEl.removeEventListener('hidden.bs.modal', onHide);
            location.reload();
        };
        modalEl.addEventListener('hidden.bs.modal', onHide);
    }
});

// --- 5. MAIL SYNC & OUTLOOK ---
function showOutlookPreview() {
    const renderZone = document.getElementById('outlook-html-render');
    
    const containerStyle = "font-family: 'Segoe UI', Arial, sans-serif; color: #1e293b; line-height: 1.4;";
    const h2Style = "color: #0f172a; margin: 0 0 5px 0; font-size: 18px; border-bottom: 2px solid #3b82f6; padding-bottom: 8px; text-transform: uppercase;";
    const progStyle = "background: #f8fafc; padding: 10px 15px; border-radius: 6px; margin-bottom: 20px; border: 1px solid #e2e8f0; font-size: 13px;";
    const projHeaderStyle = "background-color: #fff; padding: 8px 12px; border-bottom: 1px solid #e2e8f0; margin-top: 20px; font-weight: bold; color: #0f172a; font-size: 13px; text-transform: uppercase;";
    const tableStyle = "width: 100%; border-collapse: collapse; margin-top: 0;";
    const thStyle = "background-color: #f8fafc; padding: 8px 10px; border-bottom: 1px solid #cbd5e1; text-align: left; font-size: 11px; color: #64748b; text-transform: uppercase; font-weight: bold;";
    const tdStyle = "padding: 10px; border-bottom: 1px dashed #e2e8f0; vertical-align: top; font-size: 12px;";
    
    let globalProg = document.getElementById('global-progress-text').innerText;

    let html = `<div style="${containerStyle}">`;
    html += `<h2 style="${h2Style}">⚡ DAILY ENGINEERING REPORT &bull; ${window.CURRENT_DATE_STR}</h2>`;
    html += `<div style="${progStyle}">Overall Completion Status: <strong style="color: #10b981; font-size: 14px;">${globalProg}%</strong></div>`;
    html += `<p style="opacity: 0.6; margin: 0; font-size: 0.875rem;">Dear anh OK and all members,<br>I'd like share daily working plan for our members.<br>Please refer it.<br>Thank you</p>`;

    document.querySelectorAll('.report-card').forEach(card => {
        const title = card.querySelector('.project-title').innerText;
        const taskRows = card.querySelectorAll('.task-row');
        
        if (taskRows.length > 0) {
            html += `<div style="${projHeaderStyle}">${title}</div>`;
            html += `<table width="100%" cellpadding="8" cellspacing="0" style="${tableStyle}">`;
            html += `<thead><tr>
                        <th style="${thStyle} width: 28%;">Task Description & Analysis</th>
                        <th style="${thStyle} width: 25%;">Execution Checklist</th>
                        <th style="${thStyle} width: 12%; text-align: center;">Timeline</th>
                        <th style="${thStyle} width: 7%; text-align: center;">Link</th>
                        <th style="${thStyle} width: 8%;">Owner</th>
                        <th style="${thStyle} width: 10%; text-align: center;">Status</th>
                        <th style="${thStyle} width: 10%; text-align: center;">Progress</th>
                    </tr></thead><tbody>`;

            taskRows.forEach(row => {
                const taskWhat = row.querySelector('.task-title-link')?.innerText || '';
                const noteEl = row.querySelector('.analysis-box');
                const noteHtml = noteEl ? `<div style="font-size: 11px; color: #64748b; margin-top: 4px; font-style: italic;">${noteEl.innerHTML}</div>` : '';

                let checklistHtml = "";
                let counter = 1;
                row.querySelectorAll('.cl-item').forEach(c => {
                    const done = c.classList.contains('done');
                    const text = c.querySelector('span')?.innerText || '';
                    checklistHtml += `<div style="margin-bottom: 3px; font-size: 11px; color: ${done ? '#cbd5e1' : '#475569'};">
                        <span style="color: #94a3b8; font-weight: bold; margin-right: 4px;">${counter}.</span>
                        <span style="text-decoration: ${done ? 'line-through' : 'none'};">${text}</span>
                    </div>`;
                    counter++;
                });
                if (!checklistHtml) checklistHtml = '<span style="color: #cbd5e1; font-size: 11px; font-style: italic;">N/A</span>';

                const tlDiv = row.querySelector('.col-timeline');
                let timelineRender = '-';
                if (tlDiv) {
                    let lines = tlDiv.innerText.trim().split(/\n|→|->|▶|🚩/).map(s => s.trim()).filter(s => s.length > 0);
                    if (lines.length >= 2) {
                        timelineRender = `
                            <div style="font-size: 10px; color: #64748b; text-align: left; display: inline-block;">
                                <div style="margin-bottom: 2px;"><span style="color: #10b981; margin-right: 4px;">▶</span>${lines[0]}</div>
                                <div> <span style="color: #f43f5e; margin-right: 4px;">🚩</span>${lines[1]}</div>
                            </div>
                        `;
                    } else {
                        timelineRender = `<div style="font-size: 10px; color: #64748b;">${lines[0] || tlDiv.innerText}</div>`;
                    }
                }

                const linkInput = row.querySelector('.col-docs input');
                const linkVal = linkInput ? linkInput.value.trim() : '';
                const docsLinks = linkVal ? `<a href="${linkVal}" style="color: #2563eb; text-decoration: none; font-size: 11px; font-weight: bold; background: #eff6ff; padding: 2px 4px; border-radius: 4px;">🔗</a>` : '<span style="color: #cbd5e1;">-</span>';

                const pic = row.querySelector('.col-owner')?.innerText || '';
                const picHtml = `<span style="text-transform: capitalize; font-weight: 600; font-size: 11px; color: #0f172a;">${pic}</span>`;

                const statusPill = row.querySelector('.status-pill');
                const statusText = statusPill ? statusPill.innerText.trim().toUpperCase() : '';
                let statusStyle = "border-radius: 4px; padding: 3px 6px; font-size: 9px; font-weight: bold; text-transform: uppercase; display: inline-block;";
                if (statusText === 'DONE') statusStyle += " background-color: #f0fdf4; color: #166534;";
                else if (statusText === 'PENDING') statusStyle += " background-color: #f8fafc; color: #64748b;";
                else statusStyle += " background-color: #eff6ff; color: #1e40af;";
                const statusHtml = `<div style="${statusStyle}">${statusText}</div>`;

                const progText = row.querySelector('td:last-child span')?.innerText || '0%';
                const progNum = parseInt(progText) || 0;
                const progHtml = `
                    <div style="font-size: 10px; font-weight: bold; color: ${progNum === 100 ? '#166534' : '#1e293b'}; text-align: center; margin-bottom: 4px;">${progText}</div>
                    <div style="background-color: #f1f5f9; height: 4px; width: 100%; border-radius: 2px; overflow: hidden;">
                        <div style="background-color: ${progNum === 100 ? '#10b981' : '#3b82f6'}; height: 100%; width: ${progNum}%;"></div>
                    </div>
                `;

                html += `<tr>
                    <td style="${tdStyle}">
                        <strong style="color: #0f172a; display: block; font-size: 12.5px;">${taskWhat}</strong>
                        ${noteHtml}
                    </td>
                    <td style="${tdStyle}">${checklistHtml}</td>
                    <td align="center" style="${tdStyle}">${timelineRender}</td>
                    <td align="center" style="${tdStyle}">${docsLinks}</td>
                    <td style="${tdStyle}">${picHtml}</td>
                    <td align="center" style="${tdStyle}">${statusHtml}</td>
                    <td align="center" style="${tdStyle} padding-top: 14px;">${progHtml}</td>
                </tr>`;
            });
            html += `</tbody></table>`;
        }
    });
    
    const kaizenR = document.getElementById('x3-kaizen-result').value;
    const kaizenC = document.getElementById('x3-kaizen-cause').value;
    const kaizenA = document.getElementById('x3-kaizen-action').value;
    const kaizenL = document.getElementById('x3-kaizen-lesson').value;

    if (kaizenR || kaizenC || kaizenA || kaizenL) {
        html += `<div style="${projHeaderStyle}; border-left: 4px solid #8b5cf6;">KAIZEN CUỐI NGÀY</div>`;
        html += `<table width="100%" cellpadding="8" cellspacing="0" style="${tableStyle}">`;
        html += `<tr>`;
        html += `<td style="${tdStyle} width:25%;"><strong>Kết Quả:</strong><br><span style="color:#475569">${kaizenR}</span></td>`;
        html += `<td style="${tdStyle} width:25%;"><strong>Nguyên Nhân:</strong><br><span style="color:#475569">${kaizenC}</span></td>`;
        html += `<td style="${tdStyle} width:25%;"><strong>Hành Động:</strong><br><span style="color:#475569">${kaizenA}</span></td>`;
        html += `<td style="${tdStyle} width:25%;"><strong>Bài Học:</strong><br><span style="color:#475569">${kaizenL}</span></td>`;
        html += `</tr></table>`;
    }
    
    html += `<p style="margin-top: 20px; font-size: 11px; color: #94a3b8; text-align: center;">Generated by Engineering Dashboard System</p>`;
    html += `</div>`;
    
    renderZone.innerHTML = html;
    new bootstrap.Modal(document.getElementById('outlookPreviewModal')).show();
}

function copyOutlookHTML() {
    const target = document.getElementById('outlook-html-render');
    const range = document.createRange(); range.selectNode(target);
    const selection = window.getSelection(); selection.removeAllRanges(); selection.addRange(range);
    try {
        if (document.execCommand('copy')) {
            showSaveIndicator("TABLE COPIED TO CLIPBOARD!");
            setTimeout(() => { const m = bootstrap.Modal.getInstance(document.getElementById('outlookPreviewModal')); if(m) m.hide(); }, 1000);
        }
    } catch (err) { alert("Could not copy automatically. Please select the table and press Ctrl+C."); }
    selection.removeAllRanges();
}

function showSaveIndicator(msg) {
    const ind = document.getElementById('save-indicator'); ind.innerText = msg; ind.style.display = 'block';
    setTimeout(() => { ind.style.display = 'none'; }, 3000);
}