@echo off
SETLOCAL

:: Đảm bảo đang đứng ở đúng thư mục chứa file .bat
pushd "%~dp0"

SET "VENV_DIR=.venv"
SET "PYTHON_EXE=%~dp0%VENV_DIR%\Scripts\python.exe"
SET "REQUIREMENTS_FILE=requirements.txt"
SET "PYTHON_APP=run.py"

:: 1. Kiểm tra venv, nếu chưa có thì tạo mới (chỉ chạy 1 lần duy nhất trong đời dự án)
IF NOT EXIST "%PYTHON_EXE%" (
    ECHO [INFO] Creating Virtual Environment...
    python -m venv %VENV_DIR%
)

:: 2. Cập nhật thư viện (Pip đủ thông minh để bỏ qua nếu đã cài rồi)
ECHO [INFO] Checking dependencies...
"%PYTHON_EXE%" -m pip install -r "%REQUIREMENTS_FILE%" --quiet

:: 3. CHỐT HẠ: Chạy App trực tiếp bằng đường dẫn tuyệt đối động
ECHO -----------------------------------------------------
ECHO [INFO] System is ready. Starting %PYTHON_APP%...
ECHO -----------------------------------------------------

:: Gọi trực tiếp Python từ venv, nó sẽ tự hiểu mọi thư viện nằm ở đâu 
:: mà không cần quan tâm tên folder cha là gì.
"%PYTHON_EXE%" "%~dp0%PYTHON_APP%"

PAUSE
popd
ENDLOCAL