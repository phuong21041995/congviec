@echo off
color 0A
echo ===================================================
echo    BAT DAU DONG GOI UNG DUNG PLIST EXTRACTOR
echo ===================================================
echo.

:: [1/5] Kích hoạt môi trường ảo nếu có
echo [1/5] Kich hoat moi truong ao...
if exist .venv\Scripts\activate.bat (
    call .venv\Scripts\activate.bat
    echo - Da kich hoat .venv!
) else (
    echo - Khong tim thay .venv, dung moi truong he thong.
)

:: [2/5] Cài đặt thư viện
echo.
echo [2/5] Kiem tra va cai dat thu vien tu requirements.txt...
pip install -r requirements.txt --quiet

:: [3/5] Dọn dẹp folder cũ
echo.
echo [3/5] Dang don dep thu muc build cu...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist

:: [4/5] Thực hiện build
echo.
echo [4/5] Dang build ung dung voi PyInstaller...
echo Vui long cho trong giay lat...
pyinstaller launcher.spec --clean --noconfirm

:: [5/5] Đóng gói kết quả
echo.
echo [5/5] Dang nen thu muc thanh file ZIP...
if exist dist\Plist_Extractor_Pro (
    powershell Compress-Archive -Path dist\Plist_Extractor_Pro -DestinationPath dist\Plist_Extractor_Pro_Release.zip -Force
    echo.
    echo ===================================================
    echo HOAN THANH!
    echo - App nam tai: dist\Plist_Extractor_Pro\Plist_Extractor_Pro.exe
    echo - File nen tai: dist\Plist_Extractor_Pro_Release.zip
    echo ===================================================
) else (
    echo.
    echo [!] LOI: Build khong thanh cong. Vui long kiem tra lai log.
)

pause