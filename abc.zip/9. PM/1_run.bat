@echo off
SETLOCAL

SET VENV_DIR=.venv
SET PYTHON_APP=run.py
SET REQUIREMENTS_FILE=requirements.txt

ECHO [INFO] Looking for virtual environment in %VENV_DIR%...

IF NOT EXIST "%VENV_DIR%" (
    ECHO [INFO] Virtual environment not found. Creating one...
    python -m venv "%VENV_DIR%"
    IF ERRORLEVEL 1 (
        ECHO [ERROR] Failed to create virtual environment.
        PAUSE
        EXIT /B 1
    )
) ELSE (
    ECHO [INFO] Existing virtual environment found.
)

IF NOT EXIST "%VENV_DIR%\Scripts\activate.bat" (
    ECHO [ERROR] Activate script not found in "%VENV_DIR%\Scripts\activate.bat".
    PAUSE
    EXIT /B 1
)

CALL "%VENV_DIR%\Scripts\activate.bat"

IF EXIST "%REQUIREMENTS_FILE%" (
    ECHO [INFO] Installing/updating libraries from %REQUIREMENTS_FILE%...
    pip install -r "%REQUIREMENTS_FILE%"
) ELSE (
    ECHO [WARNING] %REQUIREMENTS_FILE% not found. Skipping library installation.
)

ECHO -----------------------------------------------------
ECHO [INFO] Starting the application: %PYTHON_APP%
ECHO [INFO] A child cmd window will open. Press Ctrl+C there to stop the Python process.
ECHO -----------------------------------------------------

REM Explicitly run python in a new window, keep window open after exit so you can see errors
START "" cmd /k "CALL "%VENV_DIR%\Scripts\activate.bat" & python "%~dp0%PYTHON_APP%" & echo. & echo Child process exited. & pause"

REM RETURN HERE AFTER child window CLOSED (if you manually close it)
ECHO -----------------------------------------------------
ECHO [INFO] Returned to launcher script.
PAUSE

ENDLOCAL
