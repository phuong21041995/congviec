import sqlite3
import os

db_paths = ['database.db', 'personal.db']

def upgrade_database(db_path):
    if not os.path.exists(db_path):
        return

    print(f"\n>>> Đang kiểm tra database: {db_path}")
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # ==========================================
        # XÓA BẢNG CŨ (NẾU CÓ) VÀ TẠO BẢNG LINE_STATUS MỚI
        # ==========================================
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='line_status'")
        if cursor.fetchone():
            print(f"   [+] Đang làm mới bảng 'line_status' (Cập nhật cột build_name)...")
            cursor.execute("DROP TABLE line_status")
            
        cursor.execute("""
            CREATE TABLE line_status (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                report_date DATE NOT NULL,
                project_id INTEGER NOT NULL,
                build_name VARCHAR(100) NOT NULL,
                process VARCHAR(100) NOT NULL,
                inline INTEGER DEFAULT 1,
                gib INTEGER DEFAULT 0,
                takt_time FLOAT DEFAULT 0.0,
                efficiency FLOAT DEFAULT 100.0,
                ch FLOAT DEFAULT 0.0,
                ch_available FLOAT DEFAULT 0.0,
                capa FLOAT DEFAULT 0.0,
                issue TEXT,
                reason TEXT,
                action TEXT,
                status VARCHAR(50) DEFAULT 'Running',
                link VARCHAR(500),
                FOREIGN KEY(project_id) REFERENCES project(id)
            )
        """)
        cursor.execute("CREATE INDEX idx_line_status_date ON line_status(report_date)")
        cursor.execute("CREATE INDEX idx_line_status_project ON line_status(project_id)")
        print(f"   [v] Đã cấu trúc lại bảng 'line_status' thành công.")

    except Exception as e:
        print(f"   [X] Lỗi: {e}")
    finally:
        conn.commit()
        conn.close()

if __name__ == "__main__":
    print("==========================================")
    print("DB UPGRADE TOOL - LINE STATUS UPDATE")
    print("==========================================")
    
    found_any = False
    for path in db_paths:
        if os.path.exists(path):
            upgrade_database(path)
            found_any = True
            
    if not found_any:
        print("Không tìm thấy file database nào.")
    else:
        print("\n[XONG] Database đã được nâng cấp thành công!")